"""Kalibrasyon kumesi VAL'den secilir, degerlendirme TEST'in TAMAMINDA yapilir (test etiketi kullanilmaz).

kalibrasyon.py ile ayni yontem; farklar: (1) n goruntu val kumesinden rastgele secilir, k_hat val tahminlerinden
hesaplanir (once val_tahmin.py calismali); (2) AP testin tum goruntulerinde hesaplanir (hicbiri disarida birakilmaz).
n grid'i daha ince: kac goruntu yeter sorusu icin.
SALT OKUR. Yazdigi tek yer kalibrasyon/cikti_val/.
    python kalibrasyon/kalibrasyon_val.py [--reps 100] [--jobs 10] [--deneme]
"""
import argparse
import math
import re
import sys
import time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
OUT = HERE / "cikti_val"
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(ROOT / "analiz"))
sys.path.insert(0, str(ROOT))
import kalibrasyon as K  # noqa: E402  (tp_table, per_image_ratios, load_preds, GRID, NC)

NS = [3, 5, 10, 15, 20, 30, 50, 100]


def load_val_preds(f):
    p = pd.read_csv(f)
    return {img: (g["cls"].to_numpy().astype(int), g["conf"].to_numpy(), g[["xc", "yc", "w", "h"]].to_numpy())
            for img, g in p.groupby("image")}


def read_xywh(labels_dir):
    out = {}
    for f in sorted(Path(labels_dir).glob("*.txt")):
        a = np.loadtxt(f, ndmin=2)
        out[f.stem + ".jpg"] = a[:, 1:5] if a.size else np.zeros((0, 4))
    return out


def job(args):
    model, seed, margin, reps = args
    from sehir_wald import ap_weighted
    from shrink_back_rebuild import load_gt
    t0 = time.time()
    gt = load_gt(ROOT / "dataset" / "labels" / "test")
    imgs = sorted(gt)
    img_idx = {k: i for i, k in enumerate(imgs)}
    gt_cnt = np.zeros((len(imgs), K.NC))
    for i, k in enumerate(imgs):
        np.add.at(gt_cnt[i], gt[k][0], 1)
    gt_val = read_xywh(ROOT / "dataset" / "labels" / "val")
    imgs_val = sorted(gt_val)

    name = lambda m: f"{model}_m{'n' if m < 0 else ''}{abs(m):03d}_s{seed}"  # noqa: E731
    P = K.load_preds(name(margin))                                  # TEST tahminleri (degerlendirme)
    base = K.tp_table(K.load_preds(name(0)), gt, imgs, img_idx, 1.0)
    P_val = load_val_preds(OUT / f"{name(margin)}.csv.gz")           # VAL tahminleri (kalibrasyon)
    ratios = K.per_image_ratios(P_val, gt_val, imgs_val)
    k_true = 1 + margin / 100
    f_true = 1 / math.sqrt(k_true)
    tables = {}

    def table(f):
        f = float(K.GRID[np.argmin(np.abs(K.GRID - f))]) if abs(f - 1) > 1e-9 else 1.0
        if f not in tables:
            tables[f] = K.tp_table(P, gt, imgs, img_idx, f)
        return f, tables[f]

    w = np.ones(len(imgs))
    ngt = w @ gt_cnt
    ap_b = ap_weighted(base, w, ngt).mean()
    _, t_raw = table(1.0)
    ap_r = ap_weighted(t_raw, w, ngt).mean()
    _, t_orc = table(f_true)
    ap_o = ap_weighted(t_orc, w, ngt).mean()
    rows = []
    for n in NS:
        for r in range(reps):
            rng = np.random.default_rng(1000 * n + r)
            cal = rng.choice(len(imgs_val), n, replace=False)
            rat = np.concatenate([ratios[i] for i in cal])
            k_hat = float(np.median(rat)) if len(rat) else 1.0
            _, t_hat = table(1 / math.sqrt(k_hat))
            rows.append(dict(model=model, seed=seed, margin=margin, n=n, rep=r, n_boxes=len(rat), k_true=k_true,
                             k_hat=k_hat, ap_base=ap_b, ap_raw=ap_r, ap_cal=ap_weighted(t_hat, w, ngt).mean(),
                             ap_orc=ap_o))
    print(f"{name(margin)}: {len(rows)} satir, {time.time() - t0:.0f} s", flush=True)
    return rows


def main():
    a = argparse.ArgumentParser()
    a.add_argument("--reps", type=int, default=100)
    a.add_argument("--jobs", type=int, default=10)
    a.add_argument("--deneme", action="store_true", help="tek model, az tekrar")
    args = a.parse_args()
    jobs = []
    for run in sorted((ROOT / "runs_main").iterdir()):
        mm = re.match(r"(yolov8n|yolov10n)_(mn?)(\d{3})_s(\d)$", run.name)
        if mm and (run / "test_predictions.csv.gz").exists() and (OUT / f"{run.name}.csv.gz").exists():
            m = int(mm.group(3)) * (-1 if mm.group(2) == "mn" else 1)
            jobs.append((mm.group(1), int(mm.group(4)), m, args.reps))
    if args.deneme:
        jobs = [(m, s, g, 5) for (m, s, g, _) in jobs][:1]
    print(f"{len(jobs)} model, {args.reps} tekrar, n = {NS}", flush=True)
    rows = []
    with ProcessPoolExecutor(max_workers=args.jobs) as ex:
        for r in ex.map(job, jobs):
            rows += r
    out = OUT / ("kalibrasyon_val_deneme.csv" if args.deneme else "kalibrasyon_val_sonuclari.csv")
    pd.DataFrame(rows).to_csv(out, index=False)
    print("->", out)


if __name__ == "__main__":
    main()
