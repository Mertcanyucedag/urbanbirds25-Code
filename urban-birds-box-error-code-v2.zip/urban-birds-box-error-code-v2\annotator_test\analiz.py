"""Elle cizilen kutulari sikiz referans kutularla karsilastirir.

Her goruntude elle kutular ile dataset/labels/test kutulari acgozlu IoU eslemesiyle (IoU >= 0.3) eslenir.
Olculer: alan orani (el / sikiz), genislik ve yukseklik orani, IoU; eslesmeyen kutular ayrica sayilir.
Medyan alan orani, makaledeki kutu seviyesi p'ye (k = 1 + p/100) karsilik gelir; en yakin seviyedeki
YOLOv8n AP50-95 kaybi results_main/results.csv'den okunur.

SALT OKUR: etiket_testi/cikti/kutular.json, dataset/labels/test, results_main/results.csv.
Yazdigi tek yer etiket_testi/cikti/.
"""
import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent / "cikti"


def tight_boxes(name):
    a = np.loadtxt(ROOT / "dataset" / "labels" / "test" / (Path(name).stem + ".txt"), ndmin=2)
    if not a.size:
        return np.zeros((0, 4))
    xc, yc, w, h = a[:, 1], a[:, 2], a[:, 3], a[:, 4]
    return np.column_stack([xc - w / 2, yc - h / 2, xc + w / 2, yc + h / 2])


def iou(a, b):
    x1, y1 = np.maximum(a[0], b[0]), np.maximum(a[1], b[1])
    x2, y2 = np.minimum(a[2], b[2]), np.minimum(a[3], b[3])
    inter = max(0, x2 - x1) * max(0, y2 - y1)
    ua = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter
    return inter / ua if ua > 0 else 0.0


def main():
    drawn = json.loads((OUT / "kutular.json").read_text(encoding="utf-8"))
    rows, missed, extra = [], 0, 0
    for name, boxes in drawn.items():
        g = tight_boxes(name)
        u = np.array(boxes, dtype=float).reshape(-1, 4)
        pairs = sorted(((iou(u[j], g[i]), i, j) for i in range(len(g)) for j in range(len(u))), reverse=True)
        gi, uj = set(), set()
        for v, i, j in pairs:
            if v < 0.3 or i in gi or j in uj:
                continue
            gi.add(i), uj.add(j)
            gw, gh = g[i, 2] - g[i, 0], g[i, 3] - g[i, 1]
            uw, uh = u[j, 2] - u[j, 0], u[j, 3] - u[j, 1]
            rows.append(dict(image=name, species=name.split("_")[0], iou=v, area_ratio=uw * uh / (gw * gh),
                             w_ratio=uw / gw, h_ratio=uh / gh))
        missed += len(g) - len(gi)
        extra += len(u) - len(uj)
    d = pd.DataFrame(rows)
    d.to_csv(OUT / "karsilastirma.csv", index=False)
    q = lambda s: f"{s.median():.3f} (IQR {s.quantile(.25):.3f}–{s.quantile(.75):.3f})"  # noqa: E731
    print(f"Goruntu: {len(drawn)}, eslesen kus: {len(d)}, atlanan (bizde var sizde yok): {missed}, fazla kutu: {extra}")
    print("Alan orani (el/sikiz):  ", q(d.area_ratio))
    print("Genislik orani:          ", q(d.w_ratio))
    print("Yukseklik orani:         ", q(d.h_ratio))
    print("IoU:                     ", q(d.iou))
    p = 100 * (d.area_ratio.median() - 1)
    print(f"Medyan alan sapmasi: {p:+.1f}%  (alan orani bu kadar {'buyuk' if p > 0 else 'kucuk'})")
    print(f"Kutularin %{100 * (d.area_ratio.sub(1).abs() <= 0.03).mean():.0f}'i sikiz kutudan en fazla %3 farkli")
    res = pd.read_csv(ROOT / "results_main" / "results.csv")
    res = res[(res.model == "yolov8n") & (res.protocol == "tight") & (res.class_id.astype(str) == "all")]
    ap = res.groupby("margin").AP50_95.mean()
    lvl = float(np.clip(round(p), -10, 10))
    print(f"En yakin makale seviyesi {lvl:+.0f}%: YOLOv8n AP50-95 kaybi {100 * (ap[lvl] - ap[0.0]):+.1f} puan "
          f"(bu sapma tum etiketlere sistematik uygulansaydi)")


if __name__ == "__main__":
    main()
