"""Bolum 3.6 icin kesin sayilar (2 seed, 21 seviye): egim tabanli tur duyarliligi, guvenilirlik,
yon tutarliligi, temel basarimla iliski, bolluk iliskisi, seed varyans payi.

    python analiz/tur_bolumu_sayilar.py
"""
import csv
from collections import defaultdict
from pathlib import Path

import numpy as np
from scipy import stats

ROOT = Path(__file__).resolve().parent.parent
R = [r for r in csv.DictReader(open(ROOT / "results_main/results.csv", encoding="utf-8"))
     if r["model"] == "yolov8n" and r["protocol"] == "tight" and r["class_id"] != "all"]
ap = {(int(float(r["margin"])), int(r["seed"]), int(r["class_id"])): 100 * float(r["AP50_95"]) for r in R}
names = {int(r["class_id"]): r["class_name"].replace("Corvus monedula", "Coloeus monedula") for r in R}
C = range(25)


def slope(seed, side):
    x = np.arange(1, 11)
    y = np.array([[ap[(side * k, seed, c)] for k in x] for c in C])
    return -np.polyfit(x, y.T, 1)[0]          # pozitif = her %1 hatada kaybedilen puan


S = {(s, d): slope(s, d) for s in (0, 1) for d in (-1, 1)}
shr = (S[(0, -1)] + S[(1, -1)]) / 2
enl = (S[(0, 1)] + S[(1, 1)]) / 2
sens = (shr + enl) / 2                         # genel duyarlilik (iki yon, iki seed ortalamasi)
ap0 = np.array([(ap[(0, 0, c)] + ap[(0, 1, c)]) / 2 for c in C])


def sp(a, b):
    r, p = stats.spearmanr(a, b)
    return f"rho={r:.2f}, p={p:.3f}"


print("== Duyarlilik (egim, puan / %1 hata), iki seed ort.")
print(f"  daraltma: ort {shr.mean():.2f} (aralik {shr.min():.2f}-{shr.max():.2f}); "
      f"genisletme: ort {enl.mean():.2f} (aralik {enl.min():.2f}-{enl.max():.2f})")
o = np.argsort(-sens)
print("  en duyarli 3:", "; ".join(f"{names[i]} {sens[i]:.2f}" for i in o[:3]))
print("  en dayanikli 3:", "; ".join(f"{names[i]} {sens[i]:.2f}" for i in o[::-1][:3]))
print("  tam sira:", ", ".join(f"{k + 1}.{names[i].split()[0][:4]}.{names[i].split()[1][:5]}" for k, i in enumerate(o)))

print("\n== Guvenilirlik (seed0 egimi vs seed1 egimi)")
print("  daraltma:", sp(S[(0, -1)], S[(1, -1)]), "| genisletme:", sp(S[(0, 1)], S[(1, 1)]),
      "| genel:", sp((S[(0, -1)] + S[(0, 1)]) / 2, (S[(1, -1)] + S[(1, 1)]) / 2))
for nm, a, b in (("daraltma", S[(0, -1)], S[(1, -1)]), ("genisletme", S[(0, 1)], S[(1, 1)]),
                 ("genel", (S[(0, -1)] + S[(0, 1)]) / 2, (S[(1, -1)] + S[(1, 1)]) / 2)):
    obs = np.var((a + b) / 2, ddof=1)
    noise = np.var(a - b, ddof=1) / 4
    print(f"  {nm}: gozlenen yayilimin gercek payi ~%{100 * max(0, obs - noise) / obs:.0f}")

print("\n== Yon tutarliligi (daraltma egimi vs genisletme egimi; ortak %0 noktasi yok)")
print("  iki seed ort.:", sp(shr, enl), "| capraz (shr s0 vs enl s1):", sp(S[(0, -1)], S[(1, 1)]),
      "| capraz (shr s1 vs enl s0):", sp(S[(1, -1)], S[(0, 1)]))

print("\n== Temel basarimla iliski (duyarlilik vs %0 AP)")
print("  genel:", sp(sens, ap0), "| daraltma:", sp(shr, ap0), "| genisletme:", sp(enl, ap0))
ap0s = {s: np.array([ap[(0, s, c)] for c in C]) for s in (0, 1)}
print("  bagimsiz seed (egim s0 vs AP0 s1):", sp((S[(0, -1)] + S[(0, 1)]) / 2, ap0s[1]),
      "| (egim s1 vs AP0 s0):", sp((S[(1, -1)] + S[(1, 1)]) / 2, ap0s[0]))

cnt = defaultdict(float)
for r in csv.DictReader(open(ROOT / "refs/city_shares_25.csv", encoding="utf-8")):
    cnt[int(r["class_id"])] += float(r["count"])
ab = np.array([cnt[c] for c in C])
print("\n== Bolluk iliskisi (duyarlilik vs alti sehirde sayilan birey):", sp(sens, ab))
rank = {names[i]: k + 1 for k, i in enumerate(o)}
print("  Columba livia sirasi:", rank["Columba livia"], "| Passer italiae:", rank["Passer italiae"])
print("  %0 AP en dusuk/en yuksek:", names[int(np.argmin(ap0))], f"{ap0.min() / 100:.3f}", "/",
      names[int(np.argmax(ap0))], f"{ap0.max() / 100:.3f}")

# varyans ayristirmasi (21 seviye)
L = list(range(-10, 11))
Y = np.array([[[ap[(m, s, c)] for s in (0, 1)] for m in L] for c in C])
g, spm, lvm, cell = Y.mean(), Y.mean(axis=(1, 2)), Y.mean(axis=(0, 2)), Y.mean(axis=2)
ss = {"seviye": 50 * ((lvm - g) ** 2).sum(), "tur": 42 * ((spm - g) ** 2).sum(),
      "tur x seviye": 2 * ((cell - spm[:, None] - lvm[None, :] + g) ** 2).sum(),
      "seed": ((Y - cell[:, :, None]) ** 2).sum()}
tot = sum(ss.values())
print("\n== Varyans payi (21 seviye):", ", ".join(f"{k} %{100 * v / tot:.1f}" for k, v in ss.items()))
md = (Y - Y[:, [L.index(0)], :]).mean(axis=0)
msk = np.array([abs(m) >= 3 for m in L])
print(f"  ortalama kayipta seed farki / kayip (|p|>=3): %{100 * np.abs(md[:, 1] - md[:, 0])[msk].mean() / np.abs(md.mean(axis=1))[msk].mean():.1f}")
