"""Bolum 3.7 sekli (makalede Sekil 5; sehir sekli Sekil 6 olur): YOLOv8n (2 seed ort.) ile YOLOv10n karsilastirmasi, Sekil 3 stiliyle, 174 x 64 mm.
(a) ortalama dAP50-95 (sıkı test, results.csv)
(b) geri olcekleme: tahmin edildigi gibi ve 1/k ile olceklenmis (shrink_back.csv)
(c) tur duyarliligi (egim, puan / %1 hata; Bolum 3.6 yontemi): YOLOv8n vs YOLOv10n

    python analiz/fig_mimari.py   -> figures/makale/resultsfigure_mimari_2seed.{pdf,png}
"""
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from scipy import stats  # noqa: E402

import fig_sonuclar as F  # noqa: E402  (stil + yardimcilar; import Sekil 3-5'i de yeniden yazar)

M, x, MM = F.M, F.x, F.MM
res, sb = F.res, F.rows(F.RES / "shrink_back_val.csv")      # analiz/val_olcekle.py
mg = F.mg


def model_is(name, seeds):
    return lambda r: r["model"] == name and int(r["seed"]) in seeds


MODELS = (("YOLOv8n", model_is("yolov8n", {0, 1}), F.NAVY, "o"),
          ("YOLOv10n", model_is("yolov10n", {0}), F.ORANGE, "s"))


def species(sel):
    sp = F.mean_by(res, lambda r: (mg(r), int(r["class_id"])), "AP50_95",
                   lambda r: sel(r) and r["protocol"] == "tight" and r["class_id"] != "all")
    return {m: np.array([100 * sp[(m, c)] for c in range(25)]) for m in M}


def slope(sp):
    k = np.arange(1, 11)
    return np.mean([-np.polyfit(k, np.array([sp[d * i] for i in k]), 1)[0] for d in (-1, 1)], axis=0)


FS = 7
fig, axs = plt.subplots(1, 3, figsize=(174 * MM, 64 * MM))
fig.subplots_adjust(left=0.07, right=0.975, bottom=0.17, top=0.88, wspace=0.55)

a = axs[0]
for name, sel, col, mk in MODELS:
    ap = F.mean_by(res, mg, "AP50_95", lambda r: sel(r) and r["protocol"] == "tight" and r["class_id"] == "all")
    F.line(a, [100 * (ap[m] - ap[0]) for m in M], col, mk, 3.0 if mk == "o" else 2.7, 1.1)
    a.plot([], [], color=col, marker=mk, ms=3.0, lw=1.1, mec="white", mew=0.4, label=name)
a.axhline(0, color=F.AXC, lw=0.5)
a.set_ylabel("ΔAP50-95 vs. 0% (percentage points)", fontsize=FS)
a.set_title("a  Mean change over 25 species", loc="left", fontsize=7.5)
a.legend(frameon=False, fontsize=6, loc="lower center", handlelength=1.8)
F.style(a, FS)

b = axs[1]
for name, sel, col, mk in MODELS:
    n = F.mean_by(res, mg, "AP50_95", lambda r: sel(r) and r["protocol"] == "tight" and r["class_id"] == "all")
    rr = F.mean_by(sb, mg, "AP50_95", lambda r: sel(r) and r["rescale"] == "rescaled")
    F.line(b, [100 * ((rr[m] if m else n[0]) - n[0]) for m in M], col, mk, 3.0 if mk == "o" else 2.7, 1.1, ls="--")
    F.line(b, [100 * (n[m] - n[0]) for m in M], col, mk, 3.0 if mk == "o" else 2.7, 1.1)
b.axhline(0, color=F.AXC, lw=0.5)
b.plot([], [], color="#222222", lw=1.1, label="As predicted")
b.plot([], [], color="#222222", lw=1.1, dashes=(4.07 / 1.1, 1.76 / 1.1), label="Rescaled by 1/k")
b.legend(frameon=False, fontsize=6, loc="lower center", handlelength=2.2)
b.set_ylabel("ΔAP50-95 vs. 0% (percentage points)", fontsize=FS)
b.set_title("b  Scale shift", loc="left", fontsize=7.5)
F.style(b, FS)

c = axs[2]
s8, s10 = slope(species(MODELS[0][1])), slope(species(MODELS[1][1]))
lo, hi = 0.9, 1.7
c.plot([lo, hi], [lo, hi], color=F.GREY, lw=0.8, dashes=(4, 2))
c.plot(s8, s10, "o", color="#3A3A3A", ms=3.0, mec="white", mew=0.4)    # nötr: nokta = tür, iki model eksenlerde
rho, p = stats.spearmanr(s8, s10)
c.text(0.04, 0.96, f"Each point = one species\nSpearman ρ = {rho:.2f}", transform=c.transAxes, fontsize=6,
       va="top", linespacing=1.4)
c.set_xlim(lo, hi)
c.set_ylim(lo, hi)
c.set_xlabel("YOLOv8n sensitivity (pp per 1%)", fontsize=FS)
c.set_ylabel("YOLOv10n sensitivity (pp per 1%)", fontsize=FS)
c.set_title("c  Species sensitivity", loc="left", fontsize=7.5)
for s in ("top", "right"):
    c.spines[s].set_visible(False)
c.yaxis.grid(True, color=F.GRIDC, lw=0.5)
c.set_axisbelow(True)
c.tick_params(labelsize=FS)

for ext in ("pdf", "png"):
    fig.savefig(F.OUT / f"resultsfigure_mimari_2seed.{ext}", dpi=600)
print(f"yazildi: resultsfigure_mimari_2seed | egim araligi v8n {s8.min():.2f}-{s8.max():.2f}, "
      f"v10n {s10.min():.2f}-{s10.max():.2f}, rho={rho:.2f} p={p:.3f}")
