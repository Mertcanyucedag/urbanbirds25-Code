"""Arkadas icin tek dosyalik, internetsiz calisan kutu cizme sayfasi uretir (secilen_50.json'daki test goruntuleri gomulu).
Sikiz kutular dahil DEGIL (kor test). Cizimler tarayicida saklanir; 'Sonuclari indir' JSON verir
(format: {"annotator", "created", "boxes": {goruntu: [[x1,y1,x2,y2], ...]}}, normalize 0-1).
SALT OKUR: dataset/images/test. Yazdigi tek yer: etiket_testi/arkadas/kutu_testi.html
"""
import base64, json
from pathlib import Path
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
names = json.loads((HERE / "secilen_50.json").read_text(encoding="utf-8"))
src = {n: "data:image/jpeg;base64," + base64.b64encode((ROOT / "dataset/images/test" / n).read_bytes()).decode() for n in names}
data = json.dumps({"images": names, "src": src})
HTML = r'''<!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Kutu Testi</title>
<style>
  :root { --bg:#f6f6f4; --fg:#1d1d1b; --muted:#6b6b66; --line:#d8d8d2; --accent:#2f6fde; }
  @media (prefers-color-scheme: dark) { :root { --bg:#161615; --fg:#ecebe7; --muted:#9a9a93; --line:#33332f; --accent:#6c9cf0; } }
  * { box-sizing: border-box; }
  body { margin:0; background:var(--bg); color:var(--fg); font:15px/1.45 system-ui, sans-serif; }
  header { display:flex; flex-wrap:wrap; gap:8px 16px; align-items:center; padding:10px 16px; border-bottom:1px solid var(--line); }
  h1 { font-size:16px; margin:0 8px 0 0; }
  .muted { color:var(--muted); }
  button, input { font:inherit; padding:6px 12px; border:1px solid var(--line); border-radius:6px; background:transparent; color:var(--fg); }
  button { cursor:pointer; }
  button.primary { background:var(--accent); border-color:var(--accent); color:#fff; }
  main { padding:12px 16px; }
  #wrap { position:relative; display:inline-block; max-width:100%; user-select:none; }
  canvas { display:block; cursor:none; touch-action:none; }
  #help { margin-top:8px; font-size:13px; }
  #done, #start { display:none; padding:24px 16px; max-width:640px; }
  .warn { color:#c0392b; }
</style>
</head>
<body>
<div id="start">
  <h2>Kutu Testi</h2>
  <p>50 fotoğraftaki her kuşu, normalde nasıl kutuya alıyorsan öyle kutuya al (fareyle sürükle). Doğru ya da yanlış yok.</p>
  <p>Adın: <input id="name" placeholder="Ad Soyad"> <button id="go" class="primary">Başla</button></p>
  <p class="muted">İlerleme bu tarayıcıda kaydedilir; sayfayı kapatıp açarsan kaldığın yerden devam eder. Bitince <b>Sonuçları indir</b> düğmesine basıp inen dosyayı Mert'e gönder.</p>
  <p id="lswarn" class="warn" style="display:none">Bu tarayıcı ilerlemeyi kaydedemiyor: sayfayı bitirene kadar kapatma, bitince hemen Sonuçları indir.</p>
</div>
<header id="hdr" style="display:none">
  <h1>Kutu Testi</h1>
  <span id="prog" class="muted"></span>
  <button id="undo" title="Z">Son kutuyu sil</button>
  <button id="clear">Temizle</button>
  <button id="prev" title="Sol ok">← Önceki</button>
  <button id="next" class="primary" title="Sağ ok / Enter">Kaydet ve sonraki →</button>
  <button id="dl">Sonuçları indir</button>
  <span id="status" class="muted"></span>
</header>
<main id="main" style="display:none">
  <div id="wrap"><canvas id="cv"></canvas></div>
  <div id="help" class="muted">Her kuşu <b>her zaman yaptığın gibi</b> kutuya al (fareyle sürükle). Fotoğrafta birden çok kuş varsa hepsini ayrı ayrı kutula. Kısayollar: Z = son kutuyu sil, → / Enter = kaydet ve sonraki, ← = önceki.</div>
</main>
<div id="done"><h2>Bitti, teşekkürler!</h2><p><button id="dl2" class="primary">Sonuçları indir</button></p><p class="muted">İnen <b>kutular_….json</b> dosyasını Mert'e gönder.</p></div>
<script>
const DATA = __DATA__;
const KEY = 'kutu_testi_50_v1';
const cv = document.getElementById('cv'), ctx = cv.getContext('2d');
let images = DATA.images, st = { name: '', boxes: {} }, idx = 0, boxes = [], img = new Image(), drag = null, hover = null, lsOk = true;
function loadState() { try { const s = localStorage.getItem(KEY); if (s) st = JSON.parse(s); } catch (e) { lsOk = false; } }
function saveState() { try { localStorage.setItem(KEY, JSON.stringify(st)); } catch (e) { lsOk = false; } }
function begin() {
  document.getElementById('start').style.display = 'none';
  document.getElementById('hdr').style.display = 'flex';
  document.getElementById('main').style.display = 'block';
  idx = images.findIndex(n => !(n in st.boxes)); if (idx < 0) idx = images.length - 1;
  load();
}
function load() {
  const name = images[idx];
  boxes = (st.boxes[name] || []).map(b => b.slice());
  img = new Image();
  img.onload = () => { cv.width = img.naturalWidth; cv.height = img.naturalHeight; fit(); draw(); };
  img.src = DATA.src[name];
  const n = Object.keys(st.boxes).length;
  document.getElementById('prog').textContent = `Fotoğraf ${idx + 1} / ${images.length} · tamamlanan ${n}`;
  document.getElementById('status').textContent = name in st.boxes ? 'kayıtlı' : '';
}
function fit() {
  const m = document.getElementById('main'), cs = getComputedStyle(m);
  const availW = m.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight) - 2;
  const availH = window.innerHeight - document.getElementById('hdr').offsetHeight - 70;
  const s = Math.min(availW / cv.width, availH / cv.height);
  cv.style.width = Math.floor(cv.width * s) + 'px'; cv.style.height = Math.floor(cv.height * s) + 'px';
}
window.addEventListener('resize', () => { if (cv.width) fit(); });
function draw() {
  ctx.drawImage(img, 0, 0);
  const lw = Math.max(2, cv.width / 400);
  ctx.lineWidth = lw; ctx.strokeStyle = '#e8590c';
  for (const b of boxes) ctx.strokeRect(b[0] * cv.width, b[1] * cv.height, (b[2] - b[0]) * cv.width, (b[3] - b[1]) * cv.height);
  if (drag) { ctx.setLineDash([lw * 3, lw * 2]); ctx.strokeRect(drag.x0, drag.y0, drag.x1 - drag.x0, drag.y1 - drag.y0); ctx.setLineDash([]); }
  if (hover) {
    const g = cv.width / cv.clientWidth;
    ctx.lineWidth = g; ctx.strokeStyle = 'rgba(0, 255, 255, 0.85)';
    ctx.beginPath(); ctx.moveTo(0, hover.y); ctx.lineTo(cv.width, hover.y); ctx.moveTo(hover.x, 0); ctx.lineTo(hover.x, cv.height); ctx.stroke();
  }
}
function pos(e) { const r = cv.getBoundingClientRect(); return { x: (e.clientX - r.left) * cv.width / r.width, y: (e.clientY - r.top) * cv.height / r.height }; }
cv.addEventListener('pointerdown', e => { const p = pos(e); drag = { x0: p.x, y0: p.y, x1: p.x, y1: p.y }; cv.setPointerCapture(e.pointerId); });
cv.addEventListener('pointermove', e => { const p = pos(e); hover = p; if (drag) { drag.x1 = p.x; drag.y1 = p.y; } draw(); });
cv.addEventListener('pointerleave', () => { hover = null; draw(); });
cv.addEventListener('pointerup', () => {
  if (!drag) return;
  const x1 = Math.max(0, Math.min(drag.x0, drag.x1)), x2 = Math.min(cv.width, Math.max(drag.x0, drag.x1));
  const y1 = Math.max(0, Math.min(drag.y0, drag.y1)), y2 = Math.min(cv.height, Math.max(drag.y0, drag.y1));
  if (x2 - x1 > 4 && y2 - y1 > 4) boxes.push([x1 / cv.width, y1 / cv.height, x2 / cv.width, y2 / cv.height]);
  drag = null; draw();
});
function save() { st.boxes[images[idx]] = boxes.map(b => b.slice()); saveState(); document.getElementById('status').textContent = lsOk ? 'kaydedildi' : 'kaydedildi (yalnız bu oturumda)'; }
function next() {
  save();
  if (idx < images.length - 1) { idx++; load(); }
  else { document.getElementById('main').style.display = 'none'; document.getElementById('hdr').style.display = 'none'; document.getElementById('done').style.display = 'block'; }
}
function prev() { save(); if (idx > 0) { idx--; load(); } }
function download() {
  const out = { annotator: st.name, created: new Date().toISOString(), n_images: images.length, n_done: Object.keys(st.boxes).length, boxes: st.boxes };
  const a = document.createElement('a');
  a.href = 'data:application/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(out, null, 1));
  const safe = (st.name || 'isimsiz').replace(/ı/g, 'i').replace(/İ/g, 'I').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^A-Za-z0-9_-]+/g, '_');
  a.download = 'kutular_' + safe + '.json';
  document.body.appendChild(a); a.click(); a.remove();
}
document.getElementById('next').onclick = next;
document.getElementById('prev').onclick = prev;
document.getElementById('undo').onclick = () => { boxes.pop(); draw(); };
document.getElementById('clear').onclick = () => { boxes = []; draw(); };
document.getElementById('dl').onclick = () => { if (boxes.length || images[idx] in st.boxes) save(); download(); };
document.getElementById('dl2').onclick = download;
document.addEventListener('keydown', e => {
  if (document.getElementById('main').style.display === 'none') return;
  if (e.key === 'ArrowRight' || e.key === 'Enter') { e.preventDefault(); next(); }
  else if (e.key === 'ArrowLeft') prev();
  else if (e.key.toLowerCase() === 'z') { boxes.pop(); draw(); }
});
loadState();
try { localStorage.setItem(KEY + '_t', '1'); localStorage.removeItem(KEY + '_t'); } catch (e) { lsOk = false; }
if (!lsOk) document.getElementById('lswarn').style.display = 'block';
if (st.name) begin();
else {
  document.getElementById('start').style.display = 'block';
  document.getElementById('go').onclick = () => { const v = document.getElementById('name').value.trim(); if (!v) { document.getElementById('name').focus(); return; } st.name = v; saveState(); begin(); };
}
</script>
</body>
</html>
'''
(HERE / "kutu_testi.html").write_text(HTML.replace("__DATA__", data), encoding="utf-8")
print("yazildi", round((HERE / "kutu_testi.html").stat().st_size / 1e6, 1), "MB")
