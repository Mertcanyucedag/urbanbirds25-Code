"""Shared helpers for the bird margin dataset pipeline."""
import csv
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
IMG_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".bmp"}

# Makaledeki Results şekil adları (kullanıcı kararı 2026-10-10). Yalnız ana çağrı (yolov8n, sıkı test,
# AP50-95) bu adları alır; diğer model/metrik çağrıları eski fig_* adını korur.
# 2026-10-10 v2: kullanıcı "her bölüme şekil kalabalık" dedi -> 3 ana şekil + ek; hepsi figures/makale/.
RESULTS_FIGS = {
    "species_margin": "makale/resultsfigure1",     # Results başı (3.1, 3.6): tür x seviye ısı haritası + ortalama eğri (08)
    "architecture": "makale/resultsfigure1",       # 3.7: aynı şekil, üst panelde v8n + v10n (08 --compare yolov10n)
    "main": "makale/resultsfigure2",               # 3.2-3.5: AP eğrileri, ölçek kayması, kutu oranı (15_fig_overall.py)
    "pr_count": "makale/resultsfigure3",           # 3.2: kesinlik/duyarlılık + sayım hatası, tek sütun (15_fig_overall.py)
    "city": "makale/resultsfigure4",               # 3.8: şehir eğrileri (11_city_score.py)
    "confusion_mn010": "makale/resultsfigureS1a",  # ek: karışıklık −10/0/+10 (07_confusion.py)
    "confusion_m000": "makale/resultsfigureS1b",
    "confusion_m010": "makale/resultsfigureS1c",
    "confusion_pooled": "makale/resultsfigureS2",  # ek: tüm seviyeler toplanmış (07 --pooled)
}


def fig_name(key, fallback, main=True):
    """Ana çağrıda RESULTS_FIGS adı, değilse eski ad."""
    return RESULTS_FIGS.get(key, fallback) if main else fallback


def load_species(path=ROOT / "species.csv"):
    with open(path, encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    for r in rows:
        r["class_id"] = int(r["class_id"])
        r["slug"] = slug(r["scientific_name"])
    return rows


def slug(name):
    return re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")


def species_dir_name(sp):
    return f"{sp['class_id']:02d}_{sp['slug']}"


def margin_name(m):
    """Folder/run name of a margin: 0 -> m000, 10 -> m010, 2.5 -> m002p5, -10 -> mn010."""
    m = float(m)
    a = abs(m)
    body = f"{int(a):03d}" if a.is_integer() else f"{a:05.1f}".replace(".", "p")
    return f"m{'n' if m < 0 else ''}{body}"


def margin_from_name(name):
    """Inverse of margin_name: 'm002p5' -> 2.5, 'm010' -> 10.0, 'mn010' -> -10.0."""
    s = name[1:]
    neg = s.startswith("n")
    v = float(s.lstrip("n").replace("p", "."))
    return -v if neg else v


def read_yolo_labels(path):
    """Return list of (cls, xc, yc, w, h) floats from a YOLO txt file."""
    out = []
    p = Path(path)
    if not p.exists():
        return out
    for line in p.read_text().splitlines():
        parts = line.split()
        if len(parts) >= 5:
            out.append((int(float(parts[0])), *map(float, parts[1:5])))
    return out


def write_yolo_labels(path, boxes):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        for c, xc, yc, w, h in boxes:
            f.write(f"{c} {xc:.6f} {yc:.6f} {w:.6f} {h:.6f}\n")


def write_data_yaml(path, dataset_root, species, splits=("train", "val", "test")):
    names = "\n".join(f"  {s['class_id']}: {s['scientific_name']}" for s in species)
    lines = [f"path: {Path(dataset_root).resolve().as_posix()}"]
    for sp in splits:
        lines.append(f"{sp}: images/{sp}")
    lines.append("names:")
    Path(path).write_text("\n".join(lines) + "\n" + names + "\n", encoding="utf-8")
