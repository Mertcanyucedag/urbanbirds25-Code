"""box_ratio.csv satirlarini kaydedilmis test tahminlerinden (test_predictions.csv.gz) yeniden uretir.

Yontem (eski box_ratio.csv ile dogrulanarak bulundu): her test goruntusunde tahminler guvene gore
sirali, gercek kutularla tur ayirt etmeden acgozlu eslestirilir (IoU >= 0.5, guven >= CONF);
eslesen her cift icin oran = tahmin kutu alani / gercek kutu alani.

    python analiz/box_ratio_rebuild.py --check          # eski seed-0 satirlariyla karsilastir
    python analiz/box_ratio_rebuild.py --runs yolov8n_m004_s1 ... --append
"""
import argparse
import csv
import gzip
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from common import margin_from_name, read_yolo_labels  # noqa: E402

FIELDS = ["model", "condition", "k", "seed", "class_id", "n", "median_ratio", "q1", "q3",
          "geo_mean_ratio", "sd_log_ratio"]


def iou(a, b):
    ax1, ay1, ax2, ay2 = a[0] - a[2] / 2, a[1] - a[3] / 2, a[0] + a[2] / 2, a[1] + a[3] / 2
    bx1, by1, bx2, by2 = b[0] - b[2] / 2, b[1] - b[3] / 2, b[0] + b[2] / 2, b[1] + b[3] / 2
    i = max(0, min(ax2, bx2) - max(ax1, bx1)) * max(0, min(ay2, by2) - max(ay1, by1))
    return i / (a[2] * a[3] + b[2] * b[3] - i + 1e-12)


def ratios(run_dir, conf, thr, class_aware, with_iou=False):
    preds = defaultdict(list)
    with gzip.open(run_dir / "test_predictions.csv.gz", "rt", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            if float(r["conf"]) >= conf:
                preds[r["image"]].append((int(r["cls"]), float(r["conf"]),
                                          *(float(r[k]) for k in ("xc", "yc", "w", "h"))))
    lbl_dir = ROOT / "dataset" / "labels" / "test"
    out = defaultdict(list)  # class_id -> ratios
    for lbl in sorted(lbl_dir.glob("*.txt")):
        gt = read_yolo_labels(lbl)
        used = set()
        for c, s, *pb in sorted(preds.get(lbl.stem + ".jpg", []), key=lambda p: -p[1]):
            best, bi = thr, None
            for i, (gc, *gb) in enumerate(gt):
                if i in used or (class_aware and gc != c):
                    continue
                v = iou(pb, gb)
                if v >= best:
                    best, bi = v, i
            if bi is not None:
                used.add(bi)
                g = gt[bi]
                out[g[0]].append((pb[2] * pb[3] / (g[3] * g[4]), best) if with_iou else pb[2] * pb[3] / (g[3] * g[4]))
    return out


def matched_ious(run_dir, conf=0.25, thr=0.5):
    """Eslesen (tahmin, gercek) ciftlerinin IoU'lari (box_ratio ile ayni esleme)."""
    per = ratios(Path(run_dir), conf, thr, False, with_iou=True)
    return np.array([iou_ for v in per.values() for _, iou_ in v])


def summarize(vals):
    v = np.asarray(vals)
    lg = np.log(v)
    return dict(n=len(v), median_ratio=float(np.median(v)), q1=float(np.quantile(v, 0.25)),
                q3=float(np.quantile(v, 0.75)), geo_mean_ratio=float(np.exp(lg.mean())),
                sd_log_ratio=float(lg.std(ddof=1)))


def rows_for(run, conf=0.25, thr=0.5, class_aware=False):
    model, cond, s = run.rsplit("_", 2)
    per = ratios(ROOT / "runs_main" / run, conf, thr, class_aware)
    k = 1 + margin_from_name(cond) / 100
    base = dict(model=model, condition=cond, k=round(k, 4), seed=int(s[1:]))
    rows = [dict(base, class_id="all", **summarize([x for v in per.values() for x in v]))]
    rows += [dict(base, class_id=c, **summarize(per[c])) for c in sorted(per)]
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--runs", nargs="*")
    ap.add_argument("--append", action="store_true")
    a = ap.parse_args()
    old = list(csv.DictReader(open(ROOT / "results_main" / "box_ratio.csv", encoding="utf-8")))
    if a.check:
        for run, cond in (("yolov8n_m000_s0", "m000"), ("yolov8n_mn010_s0", "mn010"), ("yolov8n_m010_s0", "m010")):
            ref = next(r for r in old if r["model"] == "yolov8n" and r["condition"] == cond
                       and r["seed"] == "0" and r["class_id"] == "all")
            for conf in (0.001, 0.25):
                for ca in (False, True):
                    r = rows_for(run, conf=conf, class_aware=ca)[0]
                    ok = r["n"] == int(ref["n"]) and abs(r["median_ratio"] - float(ref["median_ratio"])) < 1e-9
                    print(f"{cond} conf={conf} tur_duyarli={ca}: n={r['n']} (eski {ref['n']}) "
                          f"median={r['median_ratio']:.6f} (eski {float(ref['median_ratio']):.6f}) "
                          f"sd_log={r['sd_log_ratio']:.6f} (eski {float(ref['sd_log_ratio']):.6f}) {'AYNI' if ok else ''}")
    if a.runs:
        new = [r for run in a.runs for r in rows_for(run)]
        if a.append:
            with open(ROOT / "results_main" / "box_ratio.csv", "a", newline="", encoding="utf-8") as f:
                csv.DictWriter(f, fieldnames=FIELDS).writerows(new)
            print(f"{len(new)} satir eklendi")


if __name__ == "__main__":
    main()
