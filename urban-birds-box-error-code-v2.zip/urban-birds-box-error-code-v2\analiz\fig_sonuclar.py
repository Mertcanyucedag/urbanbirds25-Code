"""Sonuc sekilleri (Sekil 3-5) iki seed ortalamasiyla. Eski resultsfigure2/3/4 PDF'lerinden olculen stil
birebir kullanilir (boyut, yazi, isaret capi ve beyaz kenari, cizgi kalinligi, renkler).
Sekil 2 (isi haritasi) icin: analiz/fig_tur_isi.py

    python analiz/fig_sonuclar.py   -> figures/makale/resultsfigure{2,3,4}_2seed.{pdf,png}
"""
import csv
from collections import defaultdict
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
RES, OUT = ROOT / "results_main", ROOT / "figures" / "makale"
M = list(range(-10, 11))
SEEDS = {0, 1}
MM = 1 / 25.4
# eski PDF'lerden olculen renkler
NAVY, ORANGE, GREEN = "#1F4F78", "#C45912", "#5C8C3B"
GREY, PURPLE, LBLUE = "#808080", "#8F45AD", "#99B8D4"
AXC, GRIDC = "#6B6B6B", "#E3E3E3"


def rows(p):
    return list(csv.DictReader(open(p, encoding="utf-8")))


def mean_by(rs, key, val, filt):
    acc = defaultdict(list)
    for r in rs:
        if filt(r):
            acc[key(r)].append(float(r[val]))
    return {k: float(np.mean(v)) for k, v in acc.items()}


# ---------------------------------------------------------------- veri
res = rows(RES / "results.csv")
v8 = lambda r: r["model"] == "yolov8n" and int(r["seed"]) in SEEDS  # noqa: E731
mg = lambda r: int(float(r["margin"]))  # noqa: E731
tight = lambda r: v8(r) and r["protocol"] == "tight" and r["class_id"] == "all"  # noqa: E731
AP50 = mean_by(res, mg, "AP50", tight)
AP75 = mean_by(res, mg, "AP75", tight)
AP = mean_by(res, mg, "AP50_95", tight)
P = mean_by(res, mg, "precision", tight)
Rc = mean_by(res, mg, "recall", tight)
AGN = mean_by(res, mg, "AP50_95", lambda r: v8(r) and r["protocol"] == "agnostic" and r["class_id"] == "all")
rnd = [r for r in rows(ROOT / "results_random/results.csv") if r["protocol"] == "tight" and r["class_id"] == "all"]
RND_AP = float(np.mean([float(r["AP50_95"]) for r in rnd]))
MAE = mean_by(rows(RES / "counts.csv"), mg, "MAE", lambda r: v8(r) and r["group"] == "all")
# geri olcekleme Ultralytics dogrulayicisinin icinde (analiz/val_olcekle.py): olceksiz = results.csv ile ayni
sb = rows(RES / "shrink_back_val.csv")
SB_N = AP
SB_R = mean_by(sb, mg, "AP50_95", lambda r: v8(r) and r["rescale"] == "rescaled")
br = [r for r in rows(RES / "box_ratio.csv") if r["model"] == "yolov8n" and r["class_id"] == "all"]
cond = lambda m: f"m{'n' if m < 0 else ''}{abs(m):03d}"  # noqa: E731
BR = {m: {k: np.mean([float(r[k]) for r in br if r["condition"] == cond(m) and int(r["seed"]) in SEEDS])
          for k in ("median_ratio", "q1", "q3")} for m in M}
BR_RND = {k: np.mean([float(r[k]) for r in br if r["condition"] == "rnd010"]) for k in ("median_ratio", "q1", "q3")}
x = np.array(M)

# ---------------------------------------------------------------- ortak stil (eski sekillerden)
plt.rcParams.update({
    "font.family": "Arial", "pdf.fonttype": 42, "axes.edgecolor": AXC, "axes.linewidth": 0.8,
    "xtick.color": AXC, "ytick.color": AXC, "xtick.major.width": 0.8, "ytick.major.width": 0.8,
    "xtick.major.size": 3, "ytick.major.size": 3, "xtick.labelcolor": "#333333", "ytick.labelcolor": "#333333",
    "axes.labelcolor": "#222222", "lines.solid_capstyle": "round"})


def style(ax, fs, center=True):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    if center:
        ax.axvline(0, color=AXC, lw=0.5, ls=(0, (0.5, 0.825)))
    ax.set_xlim(-10.6, 10.6)
    ax.set_xticks([-10, -5, 0, 5, 10])
    ax.set_xlabel("Training box area change (%)", fontsize=fs)
    ax.yaxis.grid(True, color=GRIDC, lw=0.5)
    ax.set_axisbelow(True)
    ax.tick_params(labelsize=fs)


def line(ax, y, color, marker, ms, lw, ls="-", mew=0.4):
    ax.plot(x, y, ls=ls, color=color, lw=lw, marker=marker, ms=ms, mfc=color, mec="white", mew=mew,
            dashes=(4.07 / lw, 1.76 / lw) if ls == "--" else (None, None))


# ---------------------------------------------------------------- Sekil 3 (resultsfigure2): 174 x 64 mm
FS = 7
fig, axs = plt.subplots(1, 3, figsize=(174 * MM, 64 * MM))
fig.subplots_adjust(left=0.07, right=0.975, bottom=0.17, top=0.88, wspace=0.95)
a = axs[0]
line(a, [AP50[m] for m in M], NAVY, "o", 3.0, 1.1)
line(a, [AP75[m] for m in M], ORANGE, "s", 2.7, 1.1)
line(a, [AGN[m] for m in M], GREEN, "D", 3.0, 1.1, ls="--")
line(a, [AP[m] for m in M], GREEN, "D", 3.0, 1.1)
a.axhline(RND_AP, color=PURPLE, lw=0.9, dashes=(3.6 / 0.9, 1.8 / 0.9))
a.text(-10.3, RND_AP + 0.003, "Random ±10%", color=PURPLE, fontsize=6, va="bottom")
for y, t in ((AP50[10], "AP50"), (AP75[10], "AP75"), (AGN[10] + 0.012, "AP50-95\nspecies-agnostic"),
             (AP[10] - 0.012, "AP50-95")):
    a.text(11.2, y, t, fontsize=6, va="center", clip_on=False, color="#222222")
a.set_ylabel("Average precision (tight test boxes)", fontsize=FS)
a.set_title("a  Detection accuracy", loc="left", fontsize=7.5)
style(a, FS)

b = axs[1]
z = SB_N[0]
line(b, [100 * (SB_N[m] - z) for m in M], GREEN, "D", 3.0, 1.1)
line(b, [100 * ((SB_R[m] if m else z) - z) for m in M], GREY, "o", 3.0, 1.1, ls="--")
b.axhline(0, color=AXC, lw=0.5)
b.text(11.2, 100 * (SB_R[10] - z) + 0.4, "Rescaled\nby 1/k", fontsize=6, va="center", clip_on=False)
b.text(11.2, 100 * (SB_N[10] - z), "As predicted", fontsize=6, va="center", clip_on=False)
b.set_ylabel("ΔAP50-95 vs. 0% (percentage points)", fontsize=FS)
b.set_title("b  Scale shift", loc="left", fontsize=7.5)
style(b, FS)

c = axs[2]
c.plot(x, 1 + x / 100, color=GREY, lw=0.8, dashes=(4, 2))
c.vlines(x, [BR[m]["q1"] for m in M], [BR[m]["q3"] for m in M], color=LBLUE, lw=1.6)
c.plot(x, [BR[m]["median_ratio"] for m in M], "o", color=NAVY, ms=3.0, mec="white", mew=0.4)
c.errorbar([0], [BR_RND["median_ratio"]], yerr=[[BR_RND["median_ratio"] - BR_RND["q1"]],
           [BR_RND["q3"] - BR_RND["median_ratio"]]], fmt="D", color=PURPLE, ms=3.5, mec="white", mew=0.4,
           capsize=2, lw=0.9, capthick=0.9, zorder=5)
c.text(-0.6, BR_RND["q3"] + 0.003, "Random ±10%", color=PURPLE, fontsize=6, ha="right")
c.text(-10.3, 1.125, "Dashed: ratio = 1 + p/100\n(error fully learned)", color=GREY, fontsize=6, va="top")
c.set_ylabel("Predicted / true box area (median, IQR)", fontsize=FS)
c.set_title("c  Learned box size", loc="left", fontsize=7.5)
style(c, FS)
OUT.mkdir(parents=True, exist_ok=True)
for ext in ("pdf", "png"):
    fig.savefig(OUT / f"resultsfigure2_2seed.{ext}", dpi=600)
plt.close(fig)

# ---------------------------------------------------------------- Sekil 4 (resultsfigure3): 84 x 48 mm
FS = 6
fig, axs = plt.subplots(1, 2, figsize=(84 * MM, 48 * MM))
fig.subplots_adjust(left=0.13, right=0.98, bottom=0.21, top=0.88, wspace=0.55)
a = axs[0]
line(a, [P[m] for m in M], NAVY, "o", 2.2, 0.9, mew=0.3)
line(a, [Rc[m] for m in M], ORANGE, "s", 2.0, 0.9, ls="--", mew=0.3)
a.plot([], [], color=NAVY, marker="o", ms=2.2, lw=0.9, mec="white", mew=0.3, label="Precision")
a.plot([], [], color=ORANGE, marker="s", ms=2.0, lw=0.9, ls="--", mec="white", mew=0.3, label="Recall")
a.set_ylim(0.85, 1.0)
a.set_yticks([0.85, 0.90, 0.95, 1.00])
a.set_ylabel("Precision / recall (IoU 0.5)", fontsize=FS)
a.set_title("a  Precision and recall", loc="left", fontsize=6.5)
a.legend(frameon=False, fontsize=6, loc="lower center", ncol=2, handlelength=1.8, columnspacing=1.0)
style(a, FS)
b = axs[1]
line(b, [MAE[m] for m in M], NAVY, "o", 2.2, 0.9, mew=0.3)
b.set_ylim(0, 0.2)
b.set_yticks([0, 0.05, 0.10, 0.15, 0.20])
b.set_ylabel("Count error (MAE, birds/image)", fontsize=FS)
b.set_title("b  Counting", loc="left", fontsize=6.5)
style(b, FS)
for ext in ("pdf", "png"):
    fig.savefig(OUT / f"resultsfigure3_2seed.{ext}", dpi=600)
plt.close(fig)

# ---------------------------------------------------------------- Sekil 5 (resultsfigure4): 84 x 62 mm, sehirler
shares = defaultdict(dict)
for r in rows(ROOT / "refs/city_shares_25.csv"):
    shares[r["city"]][r["class_id"]] = float(r["share_25"])
sp = mean_by(res, lambda r: (mg(r), r["class_id"]), "AP50_95",
             lambda r: v8(r) and r["protocol"] == "tight" and r["class_id"] != "all")
plt.rcParams.update({"axes.edgecolor": "black", "xtick.color": "black", "ytick.color": "black",
                     "xtick.labelcolor": "black", "ytick.labelcolor": "black"})
fig, ax = plt.subplots(figsize=(84 * MM, 62 * MM))
fig.subplots_adjust(left=0.15, right=0.97, bottom=0.16, top=0.97)
for city in sorted(shares):
    S = {m: 100 * sum(w * sp[(m, c)] for c, w in shares[city].items()) for m in M}
    ax.plot(x, [S[m] - S[0] for m in M], "-o", ms=2.0, lw=0.8, label=city)
unw = {m: 100 * np.mean([sp[(m, str(c))] for c in range(25)]) for m in M}
ax.plot(x, [unw[m] - unw[0] for m in M], color="black", lw=1.0, dashes=(3.7, 1.6), label="Unweighted mean")
ax.axhline(0, color=GREY, lw=0.5)
ax.set_xlim(-11, 11)
ax.set_xticks(range(-10, 11, 2))
ax.tick_params(labelsize=7)
ax.set_xlabel("Training box area change (%)", fontsize=7)
ax.set_ylabel("ΔCity score vs. 0% (pp, AP50-95)", fontsize=7)
for s in ("top", "right"):
    ax.spines[s].set_visible(False)
ax.legend(frameon=False, fontsize=6, ncol=2, loc="lower center", handlelength=2.0, columnspacing=1.2)
for ext in ("pdf", "png"):
    fig.savefig(OUT / f"resultsfigure4_2seed.{ext}", dpi=600)
plt.close(fig)
print("yazildi: resultsfigure2/3/4_2seed | AP0=%.4f rnd=%.4f BR0=%.3f" % (AP[0], RND_AP, BR[0]["median_ratio"]))
