"""Geri olcekleme analizi - kayip 06b_shrink_back_preds.py'nin yeniden yazimi.

.pyc'deki aciklamaya gore: margin p ile egitilen modelin tahmin kutulari merkez sabit 1/sqrt(1+p/100) ile
olceklenir (p<0 ise buyutulur) ve orijinal SIKI test kutularina gore AP hesaplanir. AP, Ultralytics'in
ap_per_class'i ve DetectionValidator.match_predictions ile ayni esleme kuraliyla hesaplanir.
Girdi: runs_main/<model>_<margin>_s<seed>/test_predictions.csv.gz. GPU kullanmaz.

    python analiz/shrink_back_rebuild.py --check                     # eski shrink_back.csv ile karsilastir
    python analiz/shrink_back_rebuild.py --seeds 1 --append          # seed 1 satirlarini ekle
"""
import argparse
import math
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from ultralytics.utils.metrics import ap_per_class

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from common import margin_from_name  # noqa: E402

IOUV = np.linspace(0.5, 0.95, 10)


def xywh2xyxy(a):
    return np.concatenate([a[:, :2] - a[:, 2:] / 2, a[:, :2] + a[:, 2:] / 2], axis=1)


def box_iou(a, b):
    """a: (M,4) gt, b: (N,4) pred, xyxy -> (M,N)."""
    lt = np.maximum(a[:, None, :2], b[None, :, :2])
    rb = np.minimum(a[:, None, 2:], b[None, :, 2:])
    inter = np.clip(rb - lt, 0, None).prod(2)
    area = lambda x: (x[:, 2:] - x[:, :2]).prod(1)  # noqa: E731
    return inter / (area(a)[:, None] + area(b)[None, :] - inter + 1e-9)


def match(pred_cls, gt_cls, iou):
    """Ultralytics DetectionValidator.match_predictions ile ayni (use_scipy=False)."""
    correct = np.zeros((len(pred_cls), len(IOUV)), dtype=bool)
    iou = iou * (gt_cls[:, None] == pred_cls[None, :])
    for i, t in enumerate(IOUV):
        m = np.array(np.nonzero(iou >= t)).T
        if m.shape[0]:
            if m.shape[0] > 1:
                m = m[iou[m[:, 0], m[:, 1]].argsort()[::-1]]
                m = m[np.unique(m[:, 1], return_index=True)[1]]
                m = m[np.unique(m[:, 0], return_index=True)[1]]
            correct[m[:, 1].astype(int), i] = True
    return correct


def load_gt(label_dir):
    gt = {}
    for f in sorted(Path(label_dir).glob("*.txt")):
        a = np.loadtxt(f, ndmin=2)
        gt[f.stem + ".jpg"] = (a[:, 0].astype(int), xywh2xyxy(a[:, 1:5])) if a.size else \
            (np.zeros(0, int), np.zeros((0, 4)))
    return gt


def evaluate(pred, gt, factor):
    groups = dict(tuple(pred.groupby("image")))
    tps, confs, pcls, tcls = [], [], [], []
    for img, (gc, gb) in gt.items():
        tcls.append(gc)
        p = groups.get(img)
        if p is None or not len(p):
            continue
        xywh = p[["xc", "yc", "w", "h"]].to_numpy().copy()
        xywh[:, 2:] *= factor
        pb = xywh2xyxy(xywh)
        pc = p["cls"].to_numpy().astype(int)
        tps.append(match(pc, gc, box_iou(gb, pb)) if len(gc) else np.zeros((len(pc), 10), bool))
        confs.append(p["conf"].to_numpy())
        pcls.append(pc)
    res = ap_per_class(np.concatenate(tps), np.concatenate(confs), np.concatenate(pcls), np.concatenate(tcls))
    ap = res[5]
    return dict(AP50=float(ap[:, 0].mean()), AP75=float(ap[:, 5].mean()), AP50_95=float(ap.mean()))


def rows_for_run(run_dir, gt, ul):
    mm = re.match(r"(.+)_(mn?\d{3})_s(\d+)$", run_dir.name)
    model, cond, seed = mm.group(1), mm.group(2), int(mm.group(3))
    margin = margin_from_name(cond)
    pred = pd.read_csv(run_dir / "test_predictions.csv.gz")
    base = dict(model=model, margin=margin, seed=seed)
    ul_ap = ul.get((model, margin, seed), "")
    out = [dict(base, rescale="none", factor=1.0, **evaluate(pred, gt, 1.0), AP50_95_ultralytics=ul_ap)]
    if margin != 0:
        f = 1 / math.sqrt(1 + margin / 100)
        out.append(dict(base, rescale="rescaled", factor=round(f, 4), **evaluate(pred, gt, f), AP50_95_ultralytics=""))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--model", default="yolov8n")
    ap.add_argument("--seeds", type=int, nargs="*", default=[])
    ap.add_argument("--append", action="store_true")
    a = ap.parse_args()
    gt = load_gt(ROOT / "dataset" / "labels" / "test")
    res = pd.read_csv(ROOT / "results_main" / "results.csv", dtype={"class_id": str})
    t = res[(res.class_id == "all") & (res.protocol == "tight")]
    ul = {(r.model, float(r.margin), int(r.seed)): round(r.AP50_95, 4) for r in t.itertuples()}
    out_csv = ROOT / "results_main" / "shrink_back.csv"
    old = pd.read_csv(out_csv)

    if a.check:
        worst = 0.0
        for cond in ("m000", "mn010", "m010", "mn005", "m003"):
            rows = rows_for_run(ROOT / "runs_main" / f"{a.model}_{cond}_s0", gt, ul)
            for r in rows:
                o = old[(old.model == r["model"]) & (old.margin == r["margin"]) & (old.seed == r["seed"])
                        & (old.rescale == r["rescale"])].iloc[0]
                diff = max(abs(round(r[k], 4) - o[k]) for k in ("AP50", "AP75", "AP50_95"))
                worst = max(worst, diff)
                print(f"{cond} {r['rescale']:8s} AP50-95 yeni={r['AP50_95']:.4f} eski={o.AP50_95:.4f} "
                      f"AP50 {r['AP50']:.4f}/{o.AP50:.4f}  AP75 {r['AP75']:.4f}/{o.AP75:.4f}  "
                      f"{'AYNI' if diff == 0 else f'fark {diff:.4f}'}")
        print("en buyuk fark:", worst)

    if a.seeds:
        new = []
        for s in a.seeds:
            for run in sorted((ROOT / "runs_main").glob(f"{a.model}_m*_s{s}")):
                if not (run / "test_predictions.csv.gz").exists():
                    print("tahmin yok, atlandi:", run.name)
                    continue
                if ((old.model == a.model) & (old.seed == s) &
                        (old.margin == margin_from_name(run.name.split("_")[1]))).any():
                    continue
                new += rows_for_run(run, gt, ul)
                print("hesaplandi:", run.name)
        df = pd.DataFrame(new)
        for k in ("AP50", "AP75", "AP50_95"):
            df[k] = df[k].round(4)
        if a.append and len(df):
            df[old.columns].to_csv(out_csv, mode="a", header=False, index=False)
            print(f"{len(df)} satir eklendi -> {out_csv}")
        else:
            print(df.to_string())


if __name__ == "__main__":
    main()
