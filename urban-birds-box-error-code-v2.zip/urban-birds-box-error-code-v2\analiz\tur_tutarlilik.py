"""Tur bazindaki kayiplarin seed'ler arasi tutarliligi ve rhoSE / rhoBase icin ortak-referans (ayni AP0) etkisi.

Kayip = AP(m) - AP(0) ayni seed'in AP(0)'ini paylasir. AP(0)'daki seed gurultusu iki kaybi ayni yonde
kaydirir; bu, (a) -k ile +k kayiplari arasinda (rhoSE) ve (b) kayip ile AP(0) arasinda (rhoBase) gercek bir
tur etkisi olmasa bile pozitif korelasyon uretebilir. Burada referansi bagimsiz seed'den alarak test edilir.
"""
import csv
from pathlib import Path

import numpy as np
from scipy import stats

ROOT = Path(__file__).resolve().parent.parent
R = [r for r in csv.DictReader(open(ROOT / "results_main/results.csv", encoding="utf-8"))
     if r["model"] == "yolov8n" and r["protocol"] == "tight" and r["class_id"] != "all"]
ap = {(float(r["margin"]), int(r["seed"]), int(r["class_id"])): float(r["AP50_95"]) for r in R}
M1 = sorted({m for (m, s, c) in ap if s == 1})


def v(m, s):
    return np.array([ap[(m, s, c)] for c in range(25)]) * 100


print("1) Ayni seviyede tur KAYIPLARI iki seed'de tutarli mi? (kayip = AP(m) - AP(0), her seed kendi AP0'i ile)")
for m in [x for x in M1 if abs(x) >= 4]:
    l0, l1 = v(m, 0) - v(0, 0), v(m, 1) - v(0, 1)
    r, p = stats.spearmanr(l0, l1)
    print(f"   {m:+.0f}%: rho={r:+.2f} (p={p:.2f})  kayip sd: seed0 {l0.std(ddof=1):.2f}, seed1 {l1.std(ddof=1):.2f} puan")

print("\n2) Ayni seviyede tur AP DEGERLERI tutarli mi? (kayip degil, AP'nin kendisi)")
for m in (-10, 0, 5):
    print(f"   {m:+.0f}%: rho={stats.spearmanr(v(m, 0), v(m, 1))[0]:+.2f}")

print("\n3) Seed gurultusu ile turler arasi kayip farki")
noise = np.concatenate([v(m, 1) - v(m, 0) for m in M1])
print(f"   ayni kosulda iki seed arasi tur AP farki: sd={noise.std(ddof=1):.2f} puan "
      f"-> tek seed kaybinin (iki AP farki) beklenen gurultu sd'si ~{noise.std(ddof=1):.2f} puan")
l_avg = (v(-10, 0) + v(-10, 1)) / 2 - (v(0, 0) + v(0, 1)) / 2
print(f"   -10%'da iki seed ortalamali kayiplarin turler arasi sd'si: {l_avg.std(ddof=1):.2f} puan")

print("\n4) rhoBase (kayip vs AP0) ortak referans etkisi:")
for m in (-10, -9, -8, 5):
    loss_same = -(v(m, 0) - v(0, 0))          # seed0 kaybi, seed0 AP0'i ile
    r_same = stats.spearmanr(loss_same, v(0, 0))[0]
    loss_s1 = -(v(m, 1) - v(0, 1))            # seed1 kaybi ...
    r_indep = stats.spearmanr(loss_s1, v(0, 0))[0]  # ... bagimsiz seed0 AP0'ina karsi
    print(f"   {m:+.0f}%: ayni seed AP0 ile rho={r_same:+.2f} | bagimsiz seed AP0 ile rho={r_indep:+.2f}")

print("\n5) rhoSE benzeri (-k ile +k kayiplari): ayni AP0 vs bagimsiz AP0")
for k in (4, 5):
    same = stats.spearmanr(v(-k, 0) - v(0, 0), v(k, 0) - v(0, 0))[0]
    indep = stats.spearmanr(v(-k, 0) - v(0, 0), v(k, 1) - v(0, 1))[0]
    print(f"   k={k}: ayni seed (ortak AP0) rho={same:+.2f} | farkli seed (bagimsiz AP0) rho={indep:+.2f}")
