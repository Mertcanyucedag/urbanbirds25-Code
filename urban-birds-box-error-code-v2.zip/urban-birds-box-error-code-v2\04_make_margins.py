"""
Step 4 - Build one dataset variant per margin percentage.

Margin definition (resolution independent, AREA based):
    the box AREA is changed by p% (p < 0 shrinks it), keeping centre and aspect ratio:
    s = sqrt(1 + p/100),  new_w = w * s,  new_h = h * s,  new_area = area * (1 + p/100),
    then clipped to the image. (IoU of the enlarged box with the tight box = 1/(1+p/100).)

ONLY the TRAIN labels are expanded. VAL and TEST keep the original tight boxes,
so every model is evaluated against the same ground truth.

Images are hard-linked (no extra disk space; falls back to copying).

Output:
    datasets_margin/mn010/{images,labels}/{train,val,test}, data.yaml   (-10%)
    ...
    datasets_margin/m000/...
    ...
    datasets_margin/m010/...

Example:
    python 04_make_margins.py --dataset dataset            (default: -10..+10 step 1)
"""
import argparse
import math
import os
import shutil
from pathlib import Path

from tqdm import tqdm

from common import load_species, margin_name, read_yolo_labels, write_data_yaml, write_yolo_labels

SPLITS = ("train", "val", "test")


def scale_factor(pct):
    """Linear scale that enlarges the box AREA by pct% (aspect ratio kept)."""
    return math.sqrt(1 + pct / 100.0)


def expand_box(xc, yc, w, h, pct):
    """Enlarge a normalised YOLO box so its area grows by pct%, centre fixed, clip to [0, 1]."""
    s = scale_factor(pct)
    x1, x2 = xc - w * s / 2, xc + w * s / 2
    y1, y2 = yc - h * s / 2, yc + h * s / 2
    x1, y1 = max(0.0, x1), max(0.0, y1)
    x2, y2 = min(1.0, x2), min(1.0, y2)
    return (x1 + x2) / 2, (y1 + y2) / 2, x2 - x1, y2 - y1


def link_or_copy(src, dst):
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        return
    try:
        os.link(src, dst)
    except OSError:
        shutil.copy2(src, dst)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", default="dataset", help="output of step 3")
    ap.add_argument("--out", default="datasets_margin")
    ap.add_argument("--margins", type=float, nargs="+",
                    default=list(range(-10, 11)))  # -10, -9, ..., +10
    args = ap.parse_args()

    src, out = Path(args.dataset), Path(args.out)
    species = load_species()
    for m in args.margins:
        name = margin_name(m)
        dst = out / name
        clipped = 0
        n_boxes = 0
        for s in SPLITS:
            for img in tqdm(sorted((src / "images" / s).glob("*")), desc=f"{name}/{s}", leave=False):
                link_or_copy(img, dst / "images" / s / img.name)
                boxes = read_yolo_labels(src / "labels" / s / f"{img.stem}.txt")
                if s == "train" and m != 0:
                    new = []
                    for c, xc, yc, w, h in boxes:
                        nb = expand_box(xc, yc, w, h, m)
                        full = (w * scale_factor(m), h * scale_factor(m))
                        if m > 0 and (nb[2] < full[0] - 1e-6 or nb[3] < full[1] - 1e-6):
                            clipped += 1
                        new.append((c, *nb))
                    boxes = new
                n_boxes += len(boxes) if s == "train" else 0
                write_yolo_labels(dst / "labels" / s / f"{img.stem}.txt", boxes)
        write_data_yaml(dst / "data.yaml", dst, species)
        pct = 100 * clipped / n_boxes if n_boxes else 0
        print(f"{name}: margin {m}% -> {dst / 'data.yaml'}  "
              f"({clipped} train boxes clipped at image border, {pct:.1f}%)")


if __name__ == "__main__":
    main()
