"""numbers.tex makrolarini kaydedilmis sonuclardan yeniden uretir (kayip 13_numbers_tex.py yerine).

Kaynaklar: results_main/{results,counts,confusion,box_ratio,shrink_back}.csv, refs/city_shares_25.csv,
dataset/split_summary.csv. Model egitimi / GPU gerektirmez.

Kullanim:
    python analiz/numbers_rebuild.py --seeds 0 --check paper/numbers.tex     # dogrulama (eski dosyayla karsilastir)
    python analiz/numbers_rebuild.py --seeds 0 1 --out paper/numbers_2seed.tex

Yeniden uretilemeyen bloklar (kodu kayip): geri olceklenmis AP (06), rastgele hata IoU istatistikleri (17),
sehir bootstrap / Wald p (11). Bunlar --keep-from dosyasindan aynen kopyalanir ve ciktida isaretlenir.
"""
import argparse
import csv
import math
import re
from collections import defaultdict
from pathlib import Path

import numpy as np
from scipy import stats

ROOT = Path(__file__).resolve().parent.parent
RES = ROOT / "results_main"
MARGINS = list(range(-10, 11))
WORDS = ["Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten"]
# Makalede kullanilan guncel tur adlari (veri setinde eski ad)
RENAME = {"Corvus monedula": "Coloeus monedula"}
TOST_DELTA = 0.5  # pp, pilot deneyden onceden belirlenmis esdegerlik siniri


def suffix(m):
    """-10 -> mTen, 0 -> Zero, 3 -> pThree (makro adlarindaki seviye eki)."""
    return WORDS[0] if m == 0 else ("m" if m < 0 else "p") + WORDS[abs(m)]


# ---------------------------------------------------------------- bicimlendirme
def f3(x):
    return f"{x:.3f}"


def signed1(x):
    """ΔAP bicimi: $-$12.1 / +0.2 / 0.0"""
    r = round(x, 1)
    if r == 0:
        return "0.0"
    return f"$-${abs(r):.1f}" if r < 0 else f"+{r:.1f}"


def neg2(x):
    """r_rb / rho bicimi: $-$1.00 / 0.13"""
    r = round(x, 2)
    return f"$-${abs(r):.2f}" if r < 0 else f"{r:.2f}"


def pfmt(p):
    if p < 0.001:
        return "$<$0.001"
    if p < 0.01:
        return f"{p:.3f}"
    return f"{p:.2f}"


def thousands(n):
    return f"{n:,}"


def italic(name):
    return f"\\textit{{{RENAME.get(name, name)}}}"


# ---------------------------------------------------------------- veri
def read_csv(path):
    with open(path, encoding="utf-8") as f:
        return list(csv.DictReader(f))


def load_results(model, seeds):
    """{(protocol, class_id, margin): mean over seeds}, her metrik icin; ayrica seed sayisi."""
    acc = defaultdict(lambda: defaultdict(list))
    names = {}
    for r in read_csv(RES / "results.csv"):
        if r["model"] != model or int(r["seed"]) not in seeds:
            continue
        try:
            m = float(r["margin"])
        except ValueError:
            continue
        if not m.is_integer():
            continue
        key = (r["protocol"], r["class_id"], int(m))
        for k in ("AP50", "AP75", "AP50_95", "precision", "recall"):
            acc[key][k].append(float(r[k]))
        if r["class_id"] != "all":
            names[int(r["class_id"])] = r["class_name"]
    mean = {key: {k: float(np.mean(v)) for k, v in d.items()} for key, d in acc.items()}
    nseed = {key: len(d["AP50_95"]) for key, d in acc.items()}
    return mean, nseed, names


def holm(ps):
    """Holm-Bonferroni (statsmodels ile ayni)."""
    ps = np.asarray(ps, float)
    order = np.argsort(ps)
    adj = np.empty_like(ps)
    run = 0.0
    n = len(ps)
    for i, idx in enumerate(order):
        run = max(run, (n - i) * ps[idx])
        adj[idx] = min(1.0, run)
    return adj


def rank_biserial(d):
    """Eslestirilmis rank-biserial: (R+ - R-) / (R+ + R-), sifirlar haric."""
    d = np.asarray(d, float)
    d = d[d != 0]
    if len(d) == 0:
        return 0.0
    r = stats.rankdata(np.abs(d))
    rp, rm = r[d > 0].sum(), r[d < 0].sum()
    return (rp - rm) / (rp + rm)


def wilcoxon_p(d, alternative="two-sided"):
    d = np.asarray(d, float)
    if np.all(d == 0):
        return 1.0
    return float(stats.wilcoxon(d, alternative=alternative).pvalue)


def tost_p(d, delta=TOST_DELTA):
    """Iki tek yonlu t-testi (TOST): H0 |Δ| >= delta. p = max(p_alt, p_ust).
    (eski stats_*_vs0.csv p_tost ile 6. basamaga kadar ayni; Wilcoxon surumu degil.)"""
    d = np.asarray(d, float)
    p_lo = stats.ttest_1samp(d, -delta, alternative="greater").pvalue
    p_hi = stats.ttest_1samp(d, delta, alternative="less").pvalue
    return float(max(p_lo, p_hi))


# ---------------------------------------------------------------- bolumler
def sec_dataset(out):
    rows = read_csv(ROOT / "dataset" / "split_summary.csv")
    tr = sum(int(r["train_images"]) for r in rows)
    va = sum(int(r["val_images"]) for r in rows)
    te = sum(int(r["test_images"]) for r in rows)
    out["nTrain"], out["nVal"], out["nTest"], out["nImg"] = map(thousands, (tr, va, te, tr + va + te))


def sec_general(out, R, N):
    done = [m for m in MARGINS if ("tight", "all", m) in R]
    out["nSeedsMin"] = str(min(N[("tight", "all", m)] for m in done))
    out["nMarginsDone"] = str(len(done))
    blocks = [("AP", "tight", "AP50_95"), ("APfifty", "tight", "AP50"), ("APsf", "tight", "AP75"),
              ("Prec", "tight", "precision"), ("Rec", "tight", "recall"),
              ("APmatch", "expanded", "AP50_95"), ("APagn", "agnostic", "AP50_95")]
    for pre, prot, met in blocks:
        vals = {m: R[(prot, "all", m)][met] for m in done}
        for m, v in vals.items():
            out[pre + suffix(m)] = f3(v)
        out[pre + "Min"], out[pre + "Max"] = f3(min(vals.values())), f3(max(vals.values()))
    gap = {m: 100 * (R[("agnostic", "all", m)]["AP50_95"] - R[("tight", "all", m)]["AP50_95"]) for m in done}
    out["APgapZero"] = f"{gap[0]:.1f}"
    out["APgapMin"], out["APgapMax"] = f"{min(gap.values()):.1f}", f"{max(gap.values()):.1f}"


def sec_counts(out, model, seeds):
    acc = defaultdict(list)
    for r in read_csv(RES / "counts.csv"):
        if r["model"] == model and int(r["seed"]) in seeds and r["group"] == "all":
            m = float(r["margin"])
            if m.is_integer():
                acc[int(m)].append(float(r["MAE"]))
    vals = {m: float(np.mean(v)) for m, v in acc.items()}
    for m, v in vals.items():
        out["MAE" + suffix(m)] = f3(v)
    out["MAEMin"], out["MAEMax"] = f3(min(vals.values())), f3(max(vals.values()))


def sec_confusion(out, model, seeds):
    """Esleşen tespitlerde (true ve pred arka plan degil) yanlis ture atananlarin payi, %."""
    acc = defaultdict(lambda: [0, 0])  # (margin, seed) -> [wrong, matched]
    for r in read_csv(RES / "confusion.csv"):
        if r["model"] != model or int(r["seed"]) not in seeds:
            continue
        m = float(r["margin"])
        if not m.is_integer() or "background" in (r["true"], r["pred"]):
            continue
        a = acc[(int(m), int(r["seed"]))]
        a[1] += int(r["n"])
        if r["true"] != r["pred"]:
            a[0] += int(r["n"])
    per = defaultdict(list)
    for (m, s), (w, n) in acc.items():
        per[m].append(100 * w / n)
    vals = {m: float(np.mean(v)) for m, v in per.items()}
    for m, v in vals.items():
        out["confRate" + suffix(m)] = f"{v:.1f}"
    out["confRateMin"], out["confRateMax"] = f"{min(vals.values()):.1f}", f"{max(vals.values()):.1f}"


def species_ap(R, names, m, prot="tight"):
    return np.array([R[(prot, str(c), m)]["AP50_95"] for c in sorted(names)])


def sec_vs0(out, R, names):
    base = species_ap(R, names, 0)
    others = [m for m in MARGINS if m != 0 and ("tight", "all", m) in R]
    d = {m: 100 * (species_ap(R, names, m) - base) for m in others}
    p = {m: wilcoxon_p(d[m]) for m in others}
    pt = {m: tost_p(d[m]) for m in others}
    ph, pth = holm([p[m] for m in others]), holm([pt[m] for m in others])
    for i, m in enumerate(others):
        s = suffix(m)
        out["dAP" + s] = signed1(d[m].mean())
        out["nDown" + s], out["nUp" + s] = str(int((d[m] < 0).sum())), str(int((d[m] > 0).sum()))
        out["pHolm" + s] = pfmt(ph[i])
        out["rrb" + s] = neg2(rank_biserial(d[m]))
        out["pTost" + s] = pfmt(pth[i])
    out["nSigMargins"] = str(int((ph < 0.05).sum()))
    out["nEquivMargins"] = str(int((pth < 0.05).sum()))
    return d


def sec_friedman(out, R, names):
    mat = np.column_stack([species_ap(R, names, m) for m in MARGINS])  # 25 x 21
    chi, p = stats.friedmanchisquare(*mat.T)
    n, k = mat.shape
    out["FriedmanChi"] = f"{chi:.1f}"
    out["FriedmanDf"] = str(k - 1)
    out["FriedmanP"] = pfmt(p)
    out["KendallW"] = f"{chi / (n * (k - 1)):.2f}"


def sec_page(out, R, names):
    """Page trend: 0'dan uzaklastikca AP azaliyor mu (her yon icin 11 seviye)."""
    for key, side in (("PageShrinkP", [0, -1, -2, -3, -4, -5, -6, -7, -8, -9, -10]),
                      ("PageExpandP", list(range(0, 11)))):
        mat = np.column_stack([species_ap(R, names, m) for m in side])
        # page_trend_test artan siralama bekler -> azalan beklenti icin isareti cevir
        res = stats.page_trend_test(-mat)
        out[key] = pfmt(res.pvalue)


def sec_symmetry(out, d):
    ps, keys = [], []
    for k in range(1, 11):
        ps.append(wilcoxon_p(d[-k] - d[k]))
        keys.append(k)
    ph = holm(ps)
    for k, v in zip(keys, ph):
        out["symP" + WORDS[k]] = pfmt(v)
    out["symMinP"] = pfmt(min(ph))


def sec_species(out, R, names, d, model, seeds):
    sp = [names[c] for c in sorted(names)]
    ap0 = species_ap(R, names, 0)
    for tag, m in (("", -10), ("P", 10)):
        loss = d[m]
        i_max, i_min = int(np.argmin(loss)), int(np.argmax(loss))
        out[f"spMaxLoss{tag}Name"], out[f"spMaxLoss{tag}"] = italic(sp[i_max]), signed1(loss[i_max])
        out[f"spMinLoss{tag}Name"], out[f"spMinLoss{tag}"] = italic(sp[i_min]), signed1(loss[i_min])
        rho, p = stats.spearmanr(-loss, ap0)
        out[f"rhoBase{tag}"], out[f"pRhoBase{tag}"] = neg2(rho), pfmt(p)
    out["APspMinZero"], out["APspMinZeroName"] = f3(ap0.min()), italic(sp[int(np.argmin(ap0))])
    out["APspMaxZero"], out["APspMaxZeroName"] = f3(ap0.max()), italic(sp[int(np.argmax(ap0))])
    rho, p = stats.spearmanr(d[-10], d[10])
    out["rhoSE"], out["pRhoSE"] = neg2(rho), pfmt(p)
    # bolluk: alti sehirde sayilan birey (city_shares_25 'count' toplami) vs ±10% ortalama kayip
    cnt = defaultdict(float)
    for r in read_csv(ROOT / "refs" / "city_shares_25.csv"):
        cnt[int(r["class_id"])] += float(r["count"])
    ab = np.array([cnt[c] for c in sorted(names)])
    mloss = -(d[-10] + d[10]) / 2
    rho, p = stats.spearmanr(mloss, ab)
    out["rhoAbund"], out["pRhoAbund"], out["nSpAbund"] = neg2(rho), pfmt(p), str(int((ab > 0).sum()))
    out["shareTopSp"] = f"{100 * ab.max() / ab.sum():.1f}"


def sec_v10(out, names, R8, d8):
    R, _, _ = load_results("yolov10n", {0})
    have = [m for m in MARGINS if ("tight", "all", m) in R]
    for m in MARGINS:
        s = suffix(m)
        out["vtenAP" + s] = f3(R[("tight", "all", m)]["AP50_95"]) if m in have else "\\textbf{??}"
        if m != 0:
            ok = m in have and 0 in have
            out["vtendAP" + s] = signed1(100 * (R[("tight", "all", m)]["AP50_95"] - R[("tight", "all", 0)]["AP50_95"])) \
                if ok else "\\textbf{??}"
    rhos = {}
    for m in MARGINS:
        if m == 0:
            continue
        if m in have and 0 in have:
            d10 = 100 * (species_ap(R, names, m) - species_ap(R, names, 0))
            rhos[m] = stats.spearmanr(d8[m], d10)[0]
            out["rhoArch" + suffix(m)] = neg2(rhos[m])
        else:
            out["rhoArch" + suffix(m)] = "\\textbf{??}"
    out["rhoArchMin"] = neg2(min(rhos.values())) if rhos else "\\textbf{??}"


def sec_city(out, R, names):
    shares = defaultdict(dict)
    for r in read_csv(ROOT / "refs" / "city_shares_25.csv"):
        shares[r["city"]][int(r["class_id"])] = float(r["share_25"])
    score = {c: {m: 100 * sum(w * R[("tight", str(i), m)]["AP50_95"] for i, w in sh.items()) for m in MARGINS}
             for c, sh in shares.items()}
    ds = {c: {m: v - sc[0] for m, v in sc.items()} for c, sc in score.items()}
    for c in sorted(score):
        for m in MARGINS:
            out[f"dScore{c}{suffix(m)}"] = signed1(ds[c][m])
        best = max(MARGINS, key=lambda m: score[c][m])
        out[f"bestM{c}"] = f"$-${abs(best)}" if best < 0 else str(best)
    rng = {}
    for m in MARGINS:
        if m == 0:
            continue
        vals = [ds[c][m] for c in score]
        rng[m] = max(vals) - min(vals)
        out["cityRange" + suffix(m)] = f"{rng[m]:.1f}"
    out["cityMaxRange"] = f"{max(rng.values()):.1f}"


def sec_box_ratio(out, model, seeds):
    acc = defaultdict(lambda: defaultdict(list))
    for r in read_csv(RES / "box_ratio.csv"):
        if r["model"] != model or int(r["seed"]) not in seeds or r["class_id"] != "all":
            continue
        if not re.fullmatch(r"mn?\d{3}", r["condition"]):
            continue
        m = (-1 if r["condition"][1] == "n" else 1) * int(r["condition"].lstrip("mn"))
        for k in ("median_ratio", "q1", "q3", "k"):
            acc[m][k].append(float(r[k]))
    if len(acc) < len(MARGINS):
        return False  # bazi seviyeler icin box_ratio yok (yeni kosular) -> blok korunur
    dev, hiqr = [], []
    for m in MARGINS:
        a = {k: float(np.mean(v)) for k, v in acc[m].items()}
        out["boxRatio" + suffix(m)] = f3(a["median_ratio"])
        dev.append(abs(a["median_ratio"] - a["k"]))
        hiqr.append(100 * (a["q3"] - a["q1"]) / 2)  # yari-IQR, oran birimi (%) - stats_random ile ayni
    out["boxRatioDevMax"] = f3(max(dev))
    out["boxRatioIQRMin"], out["boxRatioIQRMax"] = f"{min(hiqr):.1f}", f"{max(hiqr):.1f}"
    return True


def sec_shrink(out, model, seeds):
    """Geri olceklenmis AP (shrink_back.csv; analiz/shrink_back_rebuild.py). raw = olceklenmemis, ayni hesap."""
    acc = defaultdict(list)
    for r in read_csv(RES / "shrink_back.csv"):
        if r["model"] == model and int(r["seed"]) in seeds:
            acc[(int(float(r["margin"])), r["rescale"])].append(float(r["AP50_95"]))
    if any((m, "rescaled" if m else "none") not in acc for m in MARGINS):
        return False  # bazi seviyeler icin henuz satir yok -> blok korunur
    a = {k: float(np.mean(v)) for k, v in acc.items()}
    z = a[(0, "none")]
    resc = {}
    for m in MARGINS:
        if m == 0:
            out["APrescZero"] = f3(z)
            continue
        resc[m] = 100 * (a[(m, "rescaled")] - z)
        out["rescD" + suffix(m)] = signed1(resc[m])
        out["rawD" + suffix(m)] = signed1(100 * (a[(m, "none")] - z))
        out["APresc" + suffix(m)] = f3(a[(m, "rescaled")])
    out["rescDMin"], out["rescDMax"] = signed1(min(resc.values())), signed1(max(resc.values()))
    return True


def sec_random(out, R, names, d, model, seeds):
    """Rastgele kutu alani hatasi (rnd010, seed 0-2) vs 0% (secili seed'lerin ortalamasi).
    Kayip 17_random_stats yerine; eski tables/stats_random_yolov8n.csv ile dogrulandi."""
    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import box_ratio_rebuild as br

    acc = defaultdict(lambda: defaultdict(list))
    rseeds = set()
    for r in read_csv(ROOT / "results_random" / "results.csv"):
        if r["model"] != model:
            continue
        rseeds.add(int(r["seed"]))
        for k in ("AP50", "AP75", "AP50_95", "precision", "recall"):
            acc[(r["protocol"], r["class_id"])][k].append(float(r[k]))
    Rr = {k: {m: float(np.mean(v)) for m, v in dd.items()} for k, dd in acc.items()}
    out["rndAP"], out["rndAPfifty"], out["rndAPsf"] = (f3(Rr[("tight", "all")][k]) for k in ("AP50_95", "AP50", "AP75"))
    out["rndPrec"], out["rndRec"] = f3(Rr[("tight", "all")]["precision"]), f3(Rr[("tight", "all")]["recall"])
    out["rndAPagn"] = f3(Rr[("agnostic", "all")]["AP50_95"])
    mae = [float(r["MAE"]) for r in read_csv(ROOT / "results_random" / "counts.csv")
           if r["model"] == model and r["group"] == "all"]
    out["rndMAE"] = f3(float(np.mean(mae)))

    dr = 100 * (np.array([Rr[("tight", str(c))]["AP50_95"] for c in sorted(names)]) - species_ap(R, names, 0))
    n = len(dr)
    se = dr.std(ddof=1) / math.sqrt(n)
    t = stats.t.ppf(0.95, n - 1)
    out["rnddAP"], out["rnddAPmedian"] = signed1(dr.mean()), signed1(float(np.median(dr)))
    out["rndCIlo"], out["rndCIhi"] = neg2(dr.mean() - t * se), neg2(dr.mean() + t * se)
    out["rndrrb"] = neg2(rank_biserial(dr))
    out["rnddAPpmFive"] = signed1((d[-5].mean() + d[5].mean()) / 2)
    out["rnddAPpmTen"] = signed1((d[-10].mean() + d[10].mean()) / 2)
    out["rndNdown"], out["rndNup"] = str(int((dr < 0).sum())), str(int((dr > 0).sum()))
    out["rndNseeds"] = str(len(rseeds))
    out["rndpWil"], out["rndpTost"] = pfmt(wilcoxon_p(dr)), pfmt(tost_p(dr))

    # kutu orani (box_ratio.csv) ve IoU (kaydedilmis tahminler)
    br_rows = [r for r in read_csv(RES / "box_ratio.csv") if r["model"] == model and r["class_id"] == "all"]
    rnd = [r for r in br_rows if r["condition"] == "rnd010"]
    zero = [r for r in br_rows if r["condition"] == "m000" and int(r["seed"]) in seeds]
    out["rndRatio"] = f3(float(np.mean([float(r["median_ratio"]) for r in rnd])))
    out["rndHalfIQR"] = f"{np.mean([100 * (float(r['q3']) - float(r['q1'])) / 2 for r in rnd]):.1f}"
    out["rndSdLog"] = f3(float(np.mean([float(r["sd_log_ratio"]) for r in rnd])))
    out["zeroSdLog"] = f3(float(np.mean([float(r["sd_log_ratio"]) for r in zero])))

    def iou_pct(dirs, thr):
        return float(np.mean([100 * (br.matched_ious(p) >= thr).mean() for p in dirs]))

    rdirs = [ROOT / "runs_random" / f"{model}_rnd010_s{s}" for s in sorted(rseeds)]
    mdirs = {m: [ROOT / "runs_main" / f"{model}_{'mn' if m < 0 else 'm'}{abs(m):03d}_s{s}" for s in sorted(seeds)]
             for m in (0, -5, 5)}
    out["rndIouNinetyFive"], out["rndIouNinety"] = f"{iou_pct(rdirs, 0.95):.1f}", f"{iou_pct(rdirs, 0.90):.1f}"
    out["zeroIouNinetyFive"], out["zeroIouNinety"] = f"{iou_pct(mdirs[0], 0.95):.1f}", f"{iou_pct(mdirs[0], 0.90):.1f}"
    out["mFiveIouNinetyFive"] = f"{iou_pct(mdirs[-5], 0.95):.1f}"
    out["pFiveIouNinetyFive"] = f"{iou_pct(mdirs[5], 0.95):.1f}"


# ---------------------------------------------------------------- tex g/c
def parse_tex(path):
    out, order, section = {}, [], {}
    cur = ""
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        if line.startswith("% ----"):
            cur = line
        mm = re.match(r"\\newcommand\{\\(\w+)\}\{(.*)\}(\s*%.*)?$", line)
        if mm:
            out[mm.group(1)] = mm.group(2)
            order.append((mm.group(1), (mm.group(3) or "").strip()))
            section[mm.group(1)] = cur
    return out, order, section


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="yolov8n")
    ap.add_argument("--seeds", type=int, nargs="+", default=[0, 1])
    ap.add_argument("--check", help="karsilastirilacak eski numbers.tex")
    ap.add_argument("--keep-from", default=str(ROOT / "paper" / "numbers.tex"),
                    help="yeniden uretilemeyen makrolarin alinacagi dosya")
    ap.add_argument("--out")
    args = ap.parse_args()
    seeds = set(args.seeds)

    R, N, names = load_results(args.model, seeds)
    out = {}
    sec_dataset(out)
    sec_general(out, R, N)
    sec_counts(out, args.model, seeds)
    sec_confusion(out, args.model, seeds)
    box_ok = sec_box_ratio(out, args.model, seeds)
    shrink_ok = sec_shrink(out, args.model, seeds)
    d = sec_vs0(out, R, names)
    sec_friedman(out, R, names)
    sec_page(out, R, names)
    sec_symmetry(out, d)
    sec_species(out, R, names, d, args.model, seeds)
    sec_random(out, R, names, d, args.model, seeds)
    sec_v10(out, names, R, d)
    sec_city(out, R, names)

    if args.check:
        old, order, section = parse_tex(args.check)
        by_sec = defaultdict(lambda: [0, 0, []])
        for k, _ in order:
            s = by_sec[section[k]]
            if k not in out:
                continue
            s[1] += 1
            if out[k] == old[k]:
                s[0] += 1
            else:
                s[2].append(f"{k}: eski={old[k]} yeni={out[k]}")
        tot_ok = tot = 0
        for sec, (ok, n, diffs) in by_sec.items():
            missing = sum(1 for k, _ in order if section[k] == sec and k not in out)
            tot_ok, tot = tot_ok + ok, tot + n
            print(f"{ok:4d}/{n:<4d} ayni  ({missing} uretilmedi)  {sec[7:].rstrip(' -')}")
            for x in diffs[:8]:
                print("          FARK", x)
            if len(diffs) > 8:
                print(f"          ... +{len(diffs) - 8} fark")
        print(f"\nTOPLAM: uretilen {tot} makronun {tot_ok}'i birebir ayni; "
              f"{len(order) - tot} makro bu betikte uretilmiyor.")

    if args.out:
        keep, order, section = parse_tex(args.keep_from)
        lines = [f"% numbers.tex — analiz/numbers_rebuild.py ile uretildi (model {args.model}, seed {sorted(seeds)}).",
                 "% [eski] isaretli makrolar yeniden uretilemedi (kodu kayip); onceki numbers.tex'ten aynen alindi.",
                 ""]
        cur = None
        for k, comment in order:
            if section[k] != cur:
                cur = section[k]
                lines += ["", cur]
            if k in out:
                lines.append(f"\\newcommand{{\\{k}}}{{{out[k]}}}  {comment}".rstrip())
            else:
                note = f"{comment} [eski]" if comment else "% [eski]"   # her zaman TeX yorumu olmali
                lines.append(f"\\newcommand{{\\{k}}}{{{keep[k]}}}  {note}")
        Path(args.out).write_text("\n".join(lines).lstrip("\n") + "\n", encoding="utf-8")
        print("yazildi:", args.out)


if __name__ == "__main__":
    main()
