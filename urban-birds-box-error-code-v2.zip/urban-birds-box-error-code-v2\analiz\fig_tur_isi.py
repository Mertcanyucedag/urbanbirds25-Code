"""Sekil 2: tur x seviye isi haritasi (YOLOv8n, seed ortalamasi) + ust panelde ortalama dAP50-95
(YOLOv8n seed araligi golgeli, YOLOv10n ust uste). Eski resultsfigure1'in duzenini izler.

    python analiz/fig_tur_isi.py --v10 <arkadasin results.csv>  [--out analiz/cikti/sekil2_deneme.png]
"""
import argparse
import csv
from collections import defaultdict
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from matplotlib.colors import TwoSlopeNorm  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
RENAME = {"Corvus monedula": "Coloeus monedula"}
MARGINS = list(range(-10, 11))


def load(paths, model):
    """{(margin, seed, class_id): AP50_95*100} tight protokol."""
    out = {}
    for p in paths:
        for r in csv.DictReader(open(p, encoding="utf-8")):
            if r["model"] != model or r["protocol"] != "tight":
                continue
            m = float(r["margin"])
            if m.is_integer():
                out[(int(m), int(r["seed"]), r["class_id"])] = 100 * float(r["AP50_95"])
    return out


def mean_delta(ap, cid, seeds):
    """Her seviye icin, o seviyede ve %0'da bulunan seed'lerin ortalama dAP'si (ayni seed'ler)."""
    res = {}
    for m in MARGINS:
        ss = [s for s in seeds if (m, s, cid) in ap and (0, s, cid) in ap]
        if ss:
            res[m] = np.mean([ap[(m, s, cid)] - ap[(0, s, cid)] for s in ss])
    return res


def main():
    a = argparse.ArgumentParser()
    a.add_argument("--v10", nargs="*", default=[], help="ek yolov10n results.csv (arkadasin)")
    a.add_argument("--out", default=str(ROOT / "analiz/cikti/sekil2_deneme.png"))
    a.add_argument("--dergi", action="store_true",
                   help="Elsevier cift sutun: 190 mm genislik, en kucuk yazi 6 pt (hucre sayilari)")
    args = a.parse_args()

    main_csv = ROOT / "results_main/results.csv"
    v8 = load([main_csv], "yolov8n")
    v10 = load([main_csv] + args.v10, "yolov10n")
    names = {}
    for r in csv.DictReader(open(main_csv, encoding="utf-8")):
        if r["class_id"] != "all":
            names[r["class_id"]] = RENAME.get(r["class_name"], r["class_name"])
    cids = sorted(names, key=int)
    seeds8 = sorted({s for (_, s, _) in v8})

    # tur x seviye dAP (seed ortalamasi)
    D = np.full((len(cids), len(MARGINS)), np.nan)
    for i, c in enumerate(cids):
        for m, v in mean_delta(v8, c, seeds8).items():
            D[i, MARGINS.index(m)] = v
    # siralama: tum seviyelerdeki ortalama kayip (en dayanikli ustte)
    order = np.argsort(-np.nanmean(np.delete(D, MARGINS.index(0), axis=1), axis=1))
    D = D[order]
    labels = [names[cids[i]] for i in order]

    # ust panel: YOLOv8n seed bazinda tur-ortalamasi dAP
    per_seed = {s: {} for s in seeds8}
    for s in seeds8:
        for m in MARGINS:
            if all((m, s, c) in v8 for c in cids):
                per_seed[s][m] = np.mean([v8[(m, s, c)] - v8[(0, s, c)] for c in cids])
    mean8 = {m: np.mean([per_seed[s][m] for s in seeds8 if m in per_seed[s]])
             for m in MARGINS if any(m in per_seed[s] for s in seeds8)}
    lo = {m: min(per_seed[s][m] for s in seeds8 if m in per_seed[s]) for m in mean8}
    hi = {m: max(per_seed[s][m] for s in seeds8 if m in per_seed[s]) for m in mean8}
    v10m = {m: np.mean([v10[(m, 0, c)] - v10[(0, 0, c)] for c in cids])
            for m in MARGINS if all((m, 0, c) in v10 and (0, 0, c) in v10 for c in cids)}

    # dergi: 190 x 150 mm, taban yazi 7 pt, hucre sayilari 6 pt (Elsevier alt siniri)
    fs, fs_cell, fs_leg = (7, 6, 6.5) if args.dergi else (9, 5.6, 7)
    plt.rcParams.update({"font.family": "Arial", "font.size": fs, "pdf.fonttype": 42})
    fig = plt.figure(figsize=(190 / 25.4, 150 / 25.4) if args.dergi else (10, 7.4), dpi=220)
    gs = fig.add_gridspec(2, 2, height_ratios=[1.0, 4.6], width_ratios=[40, 1.1], hspace=0.06, wspace=0.03)
    ax0 = fig.add_subplot(gs[0, 0])
    ax = fig.add_subplot(gs[1, 0])
    cax = fig.add_subplot(gs[1, 1])

    x = np.arange(len(MARGINS))
    xm = [MARGINS.index(m) for m in mean8]
    ax0.fill_between(xm, [lo[m] for m in mean8], [hi[m] for m in mean8], color="0.75", lw=0, label="YOLOv8n seed range")
    ax0.plot(xm, list(mean8.values()), "-o", color="black", ms=3.5, lw=1.2, label="YOLOv8n (seed mean)")
    if args.v10:  # istege bagli: YOLOv10n ust uste (makalede kullanilmiyor; mimari karsilastirmasi ayri sekil)
        xs = [MARGINS.index(m) if m in v10m else np.nan for m in MARGINS]
        ys = [v10m.get(m, np.nan) for m in MARGINS]
        ax0.plot(xs, ys, "--s", color="#d95f02", ms=3.2, lw=1.2, label="YOLOv10n")
    ax0.axhline(0, color="0.5", lw=0.6)
    ax0.set_xlim(-0.5, len(MARGINS) - 0.5)
    ax0.set_ylabel("Mean ΔAP50-95")
    ax0.set_xticks(x)
    ax0.set_xticklabels([])
    ax0.legend(frameon=False, fontsize=fs_leg, loc="lower center", ncol=3, bbox_to_anchor=(0.5, 0.0))
    for sp in ("top", "right"):
        ax0.spines[sp].set_visible(True)

    lim = np.nanmax(np.abs(D))
    norm = TwoSlopeNorm(vmin=-lim, vcenter=0, vmax=lim)
    Dp = D.copy()
    Dp[:, MARGINS.index(0)] = np.nan
    cmap = plt.get_cmap("RdBu").copy()
    cmap.set_bad("#f5f5f5")
    im = ax.imshow(Dp, cmap=cmap, norm=norm, aspect="auto")
    for i in range(D.shape[0]):
        for j, m in enumerate(MARGINS):
            if m == 0 or np.isnan(D[i, j]):
                continue
            v = D[i, j]
            ax.text(j, i, f"{v:.1f}", ha="center", va="center", fontsize=fs_cell,
                    color="white" if abs(v) > 0.62 * lim else "black")
    ax.axvline(MARGINS.index(0), color="black", lw=1.0)
    ax.set_yticks(range(len(labels)))
    ax.set_yticklabels(labels, fontstyle="italic")
    ax.set_xticks(x)
    ax.set_xticklabels([f"{m:+d}" if m else "0" for m in MARGINS])
    ax.set_xlabel("Training box area change (%)")
    cb = fig.colorbar(im, cax=cax)
    cb.set_label("ΔAP50-95 vs. 0% (percentage points)")
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    if args.dergi:      # sabit kenar bosluklari: cikti tam 190 mm kalsin
        fig.subplots_adjust(left=0.205, right=0.93, top=0.985, bottom=0.075)
        fig.savefig(args.out, facecolor="white", dpi=600)
    else:
        fig.savefig(args.out, bbox_inches="tight", facecolor="white")
    print("yazildi:", args.out)
    print("v8n seed'ler:", seeds8, "| v10n seviyeler:", sorted(v10m))


if __name__ == "__main__":
    main()
