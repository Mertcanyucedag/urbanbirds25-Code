"""Olcek kalibrasyonu deneyi (Avian Research ret gerekcesi: "yeni yontem yok" -> pratik bir duzeltme yontemi).

Soru: Etiketleme olcegi k bilinmiyorsa, birkac siki etiketli goruntuden k tahmin edilip modelin
tahminleri 1/k_hat ile duzeltilebilir mi? Kac goruntu yeter?

Her model (hatali kutularla egitilmis) ve her n (kalibrasyon goruntu sayisi) icin R tekrar:
  1. Test kumesinden n goruntu rastgele secilir (kalibrasyon kumesi).
  2. Bu goruntulerde guven >= 0.25 tahminler siki kutularla tur ayirt etmeden IoU >= 0.5 ile eslesir
     (box_ratio ile ayni kural); k_hat = tahmin alani / gercek alan oranlarinin ortancasi.
  3. Kalan goruntulerde (degerlendirme kumesi) AP50-95: duzeltmesiz, 1/sqrt(k_hat) ile duzeltilmis,
     gercek k ile duzeltilmis (ust sinir) ve ayni goruntulerde %0 modeli (referans).
AP kayitli tahminlerden hesaplanir (Ultralytics esleme + 8.4 compute_ap). Tum kosullar ayni yolla
hesaplandigi icin kendi icinde karsilastirilabilir; mutlak degerler val aracindan ~2 puan dusuktur.

SALT OKUR: runs_main/*/test_predictions.csv.gz ve dataset/labels/test. Yazdigi tek yer kalibrasyon/cikti/.

    python kalibrasyon/kalibrasyon.py [--reps 100] [--jobs 10]
"""
import argparse
import math
import re
import sys
import time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent / "cikti"
sys.path.insert(0, str(ROOT / "analiz"))
sys.path.insert(0, str(ROOT))

NS = [5, 10, 20, 50, 100]
GRID = np.round(np.arange(0.930, 1.0701, 0.002), 3)        # kenar olcek katsayisi f (alan = f^2)
NC = 25


def load_preds(run):
    p = pd.read_csv(ROOT / "runs_main" / run / "test_predictions.csv.gz")
    return {img: (g["cls"].to_numpy().astype(int), g["conf"].to_numpy(), g[["xc", "yc", "w", "h"]].to_numpy())
            for img, g in p.groupby("image")}


def per_image_ratios(preds, gt_xywh, imgs, conf=0.25, thr=0.5):
    """box_ratio_rebuild ile ayni: guvene gore sirali, tur ayirt etmeyen acgozlu esleme."""
    from shrink_back_rebuild import box_iou, xywh2xyxy
    out = []
    for img in imgs:
        g = gt_xywh[img]
        r = []
        if img in preds and len(g):
            c, s, b = preds[img]
            keep = s >= conf
            b, s = b[keep], s[keep]
            order = np.argsort(-s, kind="stable")
            iou = box_iou(xywh2xyxy(g), xywh2xyxy(b[order]))       # (G, P)
            used = set()
            for j in range(iou.shape[1]):
                best, bi = thr, None
                for i in range(iou.shape[0]):
                    if i not in used and iou[i, j] >= best:
                        best, bi = iou[i, j], i
                if bi is not None:
                    used.add(bi)
                    pb = b[order][j]
                    r.append(pb[2] * pb[3] / (g[bi, 2] * g[bi, 3]))
        out.append(np.array(r))
    return out


def tp_table(preds, gt, imgs, img_idx, factor):
    """Kenarlari `factor` ile olceklenmis tahminler icin sinif bazinda (goruntu indeksi, TP[10]) - guvene gore sirali."""
    from shrink_back_rebuild import box_iou, match, xywh2xyxy
    cls_l, conf_l, im_l, tp_l = [], [], [], []
    for img in imgs:
        if img not in preds:
            continue
        c, s, b = preds[img]
        bb = b.copy()
        bb[:, 2:] *= factor
        gc, gb = gt[img]
        tp = match(c, gc, box_iou(gb, xywh2xyxy(bb))) if len(gc) else np.zeros((len(c), 10), bool)
        cls_l.append(c), conf_l.append(s), im_l.append(np.full(len(c), img_idx[img])), tp_l.append(tp)
    cls, conf, im, tp = map(np.concatenate, (cls_l, conf_l, im_l, tp_l))
    out = []
    for k in range(NC):
        sel = np.where(cls == k)[0]
        sel = sel[np.argsort(-conf[sel], kind="stable")]
        out.append((im[sel], tp[sel].astype(float)))
    return out


def job(args):
    model, seed, margin, reps = args
    from sehir_wald import ap_weighted
    from shrink_back_rebuild import load_gt
    t0 = time.time()
    gt = load_gt(ROOT / "dataset" / "labels" / "test")
    imgs = sorted(gt)
    img_idx = {k: i for i, k in enumerate(imgs)}
    gt_xywh = {}
    for f in sorted((ROOT / "dataset" / "labels" / "test").glob("*.txt")):
        a = np.loadtxt(f, ndmin=2)
        gt_xywh[f.stem + ".jpg"] = a[:, 1:5] if a.size else np.zeros((0, 4))
    gt_cnt = np.zeros((len(imgs), NC))
    for i, k in enumerate(imgs):
        np.add.at(gt_cnt[i], gt[k][0], 1)

    name = lambda m: f"{model}_m{'n' if m < 0 else ''}{abs(m):03d}_s{seed}"  # noqa: E731
    P = load_preds(name(margin))
    base = tp_table(load_preds(name(0)), gt, imgs, img_idx, 1.0)
    ratios = per_image_ratios(P, gt_xywh, imgs)
    k_true = 1 + margin / 100
    f_true = 1 / math.sqrt(k_true)
    grid_needed = set()
    tables = {}

    def table(f):
        f = float(GRID[np.argmin(np.abs(GRID - f))]) if abs(f - 1) > 1e-9 else 1.0
        if f not in tables:
            tables[f] = tp_table(P, gt, imgs, img_idx, f)
        return f, tables[f]

    rows = []
    for n in NS:
        for r in range(reps):
            rng = np.random.default_rng(1000 * n + r)            # tum modellerde ayni kalibrasyon goruntuleri
            cal = rng.choice(len(imgs), n, replace=False)
            w = np.ones(len(imgs))
            w[cal] = 0
            ngt = w @ gt_cnt
            rat = np.concatenate([ratios[i] for i in cal]) if n else np.array([])
            k_hat = float(np.median(rat)) if len(rat) else 1.0
            f_hat, t_hat = table(1 / math.sqrt(k_hat))
            _, t_raw = table(1.0)
            f_orc, t_orc = table(f_true)
            rows.append(dict(model=model, seed=seed, margin=margin, n=n, rep=r, n_boxes=len(rat), k_true=k_true,
                             k_hat=k_hat, ap_base=ap_weighted(base, w, ngt).mean(),
                             ap_raw=ap_weighted(t_raw, w, ngt).mean(), ap_cal=ap_weighted(t_hat, w, ngt).mean(),
                             ap_orc=ap_weighted(t_orc, w, ngt).mean()))
    print(f"{name(margin)}: {len(rows)} satir, {len(tables)} olcek tablosu, {time.time() - t0:.0f} s", flush=True)
    return rows


def main():
    a = argparse.ArgumentParser()
    a.add_argument("--reps", type=int, default=100)
    a.add_argument("--jobs", type=int, default=10)
    a.add_argument("--deneme", action="store_true", help="tek model, az tekrar")
    args = a.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    jobs = []
    for run in sorted((ROOT / "runs_main").iterdir()):
        mm = re.match(r"(yolov8n|yolov10n)_(mn?)(\d{3})_s(\d)$", run.name)
        if mm and (run / "test_predictions.csv.gz").exists():
            m = int(mm.group(3)) * (-1 if mm.group(2) == "mn" else 1)
            jobs.append((mm.group(1), int(mm.group(4)), m, args.reps))
    if args.deneme:
        jobs = [(m, s, g, 5) for (m, s, g, _) in jobs if m == "yolov8n" and s == 0 and g in (-10,)]
    print(f"{len(jobs)} model, {args.reps} tekrar, n = {NS}", flush=True)
    rows = []
    with ProcessPoolExecutor(max_workers=args.jobs) as ex:
        for r in ex.map(job, jobs):
            rows += r
    out = OUT / ("deneme.csv" if args.deneme else "kalibrasyon_sonuclari.csv")
    pd.DataFrame(rows).to_csv(out, index=False)
    print("->", out)


if __name__ == "__main__":
    main()
