"""VAL kumesi icin tahmin uretir (kalibrasyonun val'den yapilabilmesi icin). EGITIM YOK, yalniz tahmin.

Her runs_main/<model>/weights/best.pt ile dataset/images/val uzerinde conf=0.001 tahmin (test_predictions ile ayni ayarlar)
-> kalibrasyon/cikti_val/<model>.csv.gz. Biten model atlanir, yarida kalirsa tekrar calistir.
SALT OKUR: runs_main, dataset. Yazdigi tek yer kalibrasyon/cikti_val/.
    python kalibrasyon/val_tahmin.py [--deneme]
"""
import argparse
import csv
import gzip
import re
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent / "cikti_val"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--batch", type=int, default=16)
    ap.add_argument("--device", default="0")
    ap.add_argument("--imgsz", type=int, default=640)
    ap.add_argument("--deneme", action="store_true", help="yalniz ilk model")
    a = ap.parse_args()
    from ultralytics import YOLO
    OUT.mkdir(exist_ok=True)
    imgs = sorted(p for p in (ROOT / "dataset" / "images" / "val").glob("*")
                  if p.suffix.lower() in (".jpg", ".jpeg", ".png"))
    runs = sorted(r for r in (ROOT / "runs_main").iterdir()
                  if re.match(r"(yolov8n|yolov10n)_(mn?)\d{3}_s\d$", r.name) and (r / "weights" / "best.pt").exists())
    if a.deneme:
        runs = runs[:1]
    print(f"{len(imgs)} val goruntusu, {len(runs)} model", flush=True)
    for k, run in enumerate(runs, 1):
        f = OUT / f"{run.name}.csv.gz"
        if f.exists():
            print(f"[{k}/{len(runs)}] atla {run.name}", flush=True)
            continue
        t0 = time.time()
        tmp = f.with_name(f.name + ".tmp")
        model = YOLO(str(run / "weights" / "best.pt"))
        with gzip.open(tmp, "wt", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            w.writerow(["image", "cls", "conf", "xc", "yc", "w", "h"])
            for i in range(0, len(imgs), a.batch):
                chunk = imgs[i:i + a.batch]
                preds = model.predict([str(p) for p in chunk], conf=0.001, imgsz=a.imgsz,
                                      device=a.device, verbose=False)
                for img, pr in zip(chunk, preds):
                    w.writerows([img.name, int(c), round(s, 5), *(round(v, 6) for v in b)] for c, s, b in
                                zip(pr.boxes.cls.tolist(), pr.boxes.conf.tolist(), pr.boxes.xywhn.tolist()))
        tmp.replace(f)
        print(f"[{k}/{len(runs)}] {run.name} {time.time() - t0:.0f} s", flush=True)


if __name__ == "__main__":
    main()
