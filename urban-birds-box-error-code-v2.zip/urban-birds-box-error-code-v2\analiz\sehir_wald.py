"""Bolum 3.8 sehir testi - kayip 11_city_score.py bootstrap/Wald kisminin yeniden yazimi (2 seed).

S_c(k) = sum_i w_ci AP_i(k);  dS_c(k) = S_c(k) - S_c(0)  (AP: seedlerin ortalamasi, yuzde puan).
H0: her seviyede alti sehrin dS_c(k) degeri esit. Wald: T = (C d)' (C V C')^-1 (C d), sd = 5,
V: bootstrap kovaryansi; her tekrarda test goruntuleri tur icinde, sayim noktalari sehir icinde ve
seedler iadeli olarak birlikte yeniden orneklenir (seviyeler arasi eslenik). Holm seviyeler arasinda.
Ayrica her sehrin en iyi seviyesinin kararliligi (2000 tekrar, 2.9) raporlanir.
AP: kayitli test tahminlerinden, Ultralytics ap_per_class ile ayni hesap (goruntu agirlikli). GPU yok.

    python analiz/sehir_wald.py [--B 1000] [--B_best 2000]
"""
import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "analiz"))
from shrink_back_rebuild import box_iou, load_gt, match, xywh2xyxy  # noqa: E402

LEVELS = list(range(-10, 11))
SEEDS = (0, 1)
NC = 25
CITY = {"CB": "Campobasso", "FI": "Florence", "MI": "Milan", "NP": "Naples", "RO": "Rome", "TO": "Turin"}
X101 = np.linspace(0, 1, 101)


def run_name(m, s):
    return f"yolov8n_m{'n' if m < 0 else ''}{abs(m):03d}_s{s}"


def prepare(run, gt, img_idx):
    """Her tahmin icin (sinif, guven, goruntu indeksi, 10 esikte TP) - sinif bazinda guvene gore sirali."""
    p = pd.read_csv(ROOT / "runs_main" / run / "test_predictions.csv.gz")
    tp = np.zeros((len(p), 10), bool)
    for img, g in p.groupby("image").groups.items():
        gi = np.asarray(g)
        sub = p.loc[gi]
        gc, gb = gt[img]
        if len(gc):
            tp[gi] = match(sub["cls"].to_numpy().astype(int), gc,
                                        box_iou(gb, xywh2xyxy(sub[["xc", "yc", "w", "h"]].to_numpy())))
    out = []
    cls, conf, im = p["cls"].to_numpy().astype(int), p["conf"].to_numpy(), p["image"].map(img_idx).to_numpy()
    for c in range(NC):
        k = np.where(cls == c)[0]
        k = k[np.argsort(-conf[k], kind="stable")]
        out.append((im[k], tp[k].astype(float)))
    return out


def ap_weighted(prep, w, ngt):
    """Goruntu agirliklari w ile tur bazli AP50-95 (Ultralytics compute_ap, 101 nokta)."""
    ap = np.zeros(NC)
    for c, (im, tp) in enumerate(prep):
        if ngt[c] == 0 or not len(im):
            continue
        ww = w[im][:, None]
        tpc = np.cumsum(tp * ww, 0)
        fpc = np.cumsum((1 - tp) * ww, 0)
        rec = tpc / (ngt[c] + 1e-16)
        pre = tpc / (tpc + fpc + 1e-16)
        s = 0.0
        for j in range(10):
            mrec = np.concatenate(([0.0], rec[:, j], [rec[-1, j]], [1.0]))     # 8.4.x: ek sentinel
            mpre = np.concatenate(([1.0], pre[:, j], [0.0], [0.0]))
            mpre = np.flip(np.maximum.accumulate(np.flip(mpre)))
            s += np.trapezoid(np.interp(X101, mrec, mpre), X101)
        ap[c] = s / 10
    return ap


def main():
    a = argparse.ArgumentParser()
    a.add_argument("--B", type=int, default=1000)
    a.add_argument("--B_best", type=int, default=2000)
    a.add_argument("--seed", type=int, default=2026)
    args = a.parse_args()
    rng = np.random.default_rng(args.seed)

    gt = load_gt(ROOT / "dataset" / "labels" / "test")
    imgs = sorted(gt)
    img_idx = {k: i for i, k in enumerate(imgs)}
    img_sp = np.array([int(i.split("_")[0]) for i in imgs])          # dosya adi "<class_id>_..."
    man = pd.read_csv(ROOT / "dataset" / "split_manifest.csv")
    assert (np.bincount(img_sp, minlength=NC) == man[man.split == "test"].class_id.value_counts().sort_index()).all()
    gt_cnt = np.zeros((len(imgs), NC))
    for i, k in enumerate(imgs):
        np.add.at(gt_cnt[i], gt[k][0], 1)
    sp_imgs = [np.where(img_sp == c)[0] for c in range(NC)]

    print("tahminler hazirlaniyor (42 model)...", flush=True)
    P = {(m, s): prepare(run_name(m, s), gt, img_idx) for m in LEVELS for s in SEEDS}

    # sehir sayimlari: nokta x tur (uc ziyaret toplami)
    cs = pd.read_csv(ROOT / "refs" / "city_shares_25.csv")
    code = cs.drop_duplicates("class_id").set_index("class_id")["code"].reindex(range(NC)).tolist()
    bc = pd.read_csv(ROOT / "refs" / "alba2025_zenodo" / "Bird_communities.csv")
    pts = bc.groupby(["City", "Point"])[code].sum()
    cities = list(CITY)
    city_pts = {c: pts.loc[c].to_numpy(float) for c in cities}
    W0 = np.array([city_pts[c].sum(0) / city_pts[c].sum() for c in cities])     # 6 x 25
    chk = cs.pivot(index="city", columns="class_id", values="share_25").loc[[CITY[c] for c in cities]].to_numpy()
    assert np.allclose(W0, chk, atol=1e-9), "sehir paylari city_shares_25.csv ile uyusmuyor"

    # nokta tahmini + Ultralytics sonuclariyla kontrol
    ones = np.ones(len(imgs))
    ngt0 = gt_cnt.sum(0)
    AP = {k: 100 * ap_weighted(v, ones, ngt0) for k, v in P.items()}
    res = pd.read_csv(ROOT / "results_main" / "results.csv", dtype={"class_id": str})
    res = res[(res.model == "yolov8n") & (res.protocol == "tight") & (res.class_id != "all")]
    ul = {(int(float(r.margin)), int(r.seed), int(r.class_id)): 100 * r.AP50_95 for r in res.itertuples()}
    dev = np.array([AP[(m, s)][c] - ul[(m, s, c)] for m in LEVELS for s in SEEDS for c in range(NC)])
    print(f"tahmin tabanli tur AP'si - results.csv (val): ort {dev.mean():.2f}, en buyuk |fark| "
          f"{np.abs(dev).max():.2f} puan (predict ile val ayni degil; nokta tahmini results.csv'den)")
    AP_pred = AP
    AP = {(m, s): np.array([ul[(m, s, c)] for c in range(NC)]) for m in LEVELS for s in SEEDS}

    def scores(ap_by_level, W):
        return np.array([W @ ap_by_level[m] for m in LEVELS])                  # 21 x 6

    def draw():
        w = np.zeros(len(imgs))
        for ix in sp_imgs:
            np.add.at(w, rng.choice(ix, len(ix)), 1)
        W = np.array([city_pts[c][rng.integers(0, len(city_pts[c]), len(city_pts[c]))].sum(0) for c in cities])
        W = W / W.sum(1, keepdims=True)
        sd = rng.choice(SEEDS, len(SEEDS))
        ngt = w @ gt_cnt
        apm = {}
        for m in LEVELS:
            apm[m] = np.mean([100 * ap_weighted(P[(m, s)], w, ngt) for s in sd], 0)
        return apm, W

    ap_mean = {m: np.mean([AP[(m, s)] for s in SEEDS], 0) for m in LEVELS}
    S = scores(ap_mean, W0)
    D = S - S[LEVELS.index(0)]
    glob_lvl = LEVELS[int(np.argmax([ap_mean[m].mean() for m in LEVELS]))]
    # bootstrap tahmin tabanli AP ile yapilir; sapmalari results.csv nokta tahmininin etrafina tasinir
    S_pred = scores({m: np.mean([AP_pred[(m, s)] for s in SEEDS], 0) for m in LEVELS}, W0)

    B = max(args.B, args.B_best)
    print(f"bootstrap {B} tekrar...", flush=True)
    Db, best_b = [], []
    for b in range(B):
        apm, W = draw()
        Sb = scores(apm, W) - S_pred + S
        Db.append(Sb - Sb[LEVELS.index(0)])
        best_b.append([LEVELS[i] for i in Sb.argmax(0)])
        if (b + 1) % 100 == 0:
            print(f"  {b + 1}/{B}", flush=True)
    Db = np.array(Db)[: args.B]
    best_b = np.array(best_b)[: args.B_best]

    C = np.hstack([-np.ones((5, 1)), np.eye(5)])
    rows = []
    for li, m in enumerate(LEVELS):
        if m == 0:
            continue
        d = D[li]
        V = np.cov(Db[:, li, :], rowvar=False)
        cd = C @ d
        T = float(cd @ np.linalg.solve(C @ V @ C.T, cd))
        dp = S_pred[li] - S_pred[LEVELS.index(0)]                    # duyarlilik: tamamen tahmin tabanli
        T_pred = float((C @ dp) @ np.linalg.solve(C @ V @ C.T, C @ dp))
        rng_pp = d.max() - d.min()
        rng_b = Db[:, li, :].max(1) - Db[:, li, :].min(1)
        rows.append(dict(margin=m, mean_dscore=d.mean(), range_pp=rng_pp,
                         most_loss=CITY[cities[int(np.argmin(d))]], least_loss=CITY[cities[int(np.argmax(d))]],
                         range_lo=2 * rng_pp - np.quantile(rng_b, 0.975), range_hi=2 * rng_pp - np.quantile(rng_b, 0.025),
                         wald_T=T, df=5, p_wald=float(stats.chi2.sf(T, 5)),
                         p_wald_predbased=float(stats.chi2.sf(T_pred, 5))))
    t = pd.DataFrame(rows)
    t["p_holm"] = np.minimum(1, np.maximum.accumulate(
        (len(t) - np.arange(len(t))) * np.sort(t.p_wald.to_numpy())))[np.argsort(np.argsort(t.p_wald.to_numpy()))]
    t["cities_differ"] = t.p_holm < 0.05
    out = ROOT / "tables" / "city_tests_yolov8n_tight_AP50_95_2seed.csv"
    t.to_csv(out, index=False)

    ci = [dict(city=CITY[c], margin=m, dscore=D[li, ci_], lo=np.quantile(Db[:, li, ci_], 0.025),
               hi=np.quantile(Db[:, li, ci_], 0.975))
          for li, m in enumerate(LEVELS) if m != 0 for ci_, c in enumerate(cities)]
    pd.DataFrame(ci).to_csv(ROOT / "tables" / "city_tests_yolov8n_tight_AP50_95_ci_2seed.csv", index=False)

    summ = []
    for ci_, c in enumerate(cities):
        best = LEVELS[int(np.argmax(S[:, ci_]))]
        vals, cnt = np.unique(best_b[:, ci_], return_counts=True)
        o = np.argsort(-cnt)[:3]
        summ.append(dict(city=CITY[c], best_margin=best, global_margin=glob_lvl,
                         p_best_is_point_estimate=float(np.mean(best_b[:, ci_] == best)),
                         bootstrap_best_top3=", ".join(f"{vals[i]:+d}% ({100 * cnt[i] / len(best_b):.0f}%)" for i in o)))
    pd.DataFrame(summ).to_csv(ROOT / "tables" / "city_yolov8n_tight_AP50_95_summary_2seed.csv", index=False)

    pd.set_option("display.width", 200)
    print(t[["margin", "mean_dscore", "range_pp", "most_loss", "least_loss", "wald_T", "p_wald", "p_holm",
             "p_wald_predbased"]]
          .round(3).to_string(index=False))
    print(pd.DataFrame(summ).to_string(index=False))
    print(f"\nduzeltmesiz en kucuk p = {t.p_wald.min():.2f} (seviye {int(t.margin[t.p_wald.idxmin()])}), "
          f"Holm sonrasi en kucuk p = {t.p_holm.min():.2f}; en buyuk sehir farki = {t.range_pp.max():.2f} puan")
    print("->", out)


if __name__ == "__main__":
    main()
