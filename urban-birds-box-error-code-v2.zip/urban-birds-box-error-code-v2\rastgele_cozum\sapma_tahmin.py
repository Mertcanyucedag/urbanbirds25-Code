"""Rastgele hata: modelin kutu boyutu sapmasi, cikarim aninda bilinen ozelliklerden tahmin edilebilir mi?

Her eslesmis tahmin (guven >= 0.25, tur ayirt etmeyen, IoU >= 0.5) icin hedef: log(tahmin alani / siki alan).
Aciklayicilar (hepsi cikarimda bilinir): tahmin edilen tur, log(tahmin kutu alani), en-boy orani, guven.
Goruntuye gore 5 katli capraz dogrulamayla (ayni goruntu hem egitim hem testte olmasin) dogrusal model;
olcut: capraz dogrulanmis R^2 ve bu modelle duzeltilen kutularin dagiliminin daralmasi.
Ayrica: ayni kus icin uc seed'in sapmalari ne kadar iliskili? (yuksekse sapma goruntuye bagli, birlestirme
az yarar; dusukse sapma modele ozgu, birlestirme yarar.)

SALT OKUR: runs_random ve runs_main tahminleri, dataset/labels/test. Yazdigi tek yer rastgele_cozum/cikti/.
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent / "cikti"
sys.path.insert(0, str(ROOT / "analiz"))
from shrink_back_rebuild import box_iou, load_gt, xywh2xyxy  # noqa: E402

NC = 25


def pairs(run_dir, gt, imgs):
    p = pd.read_csv(run_dir / "test_predictions.csv.gz")
    P = {img: g for img, g in p.groupby("image")}
    rows = []
    for ii, img in enumerate(imgs):
        gc, gb = gt[img]
        if img not in P or not len(gc):
            continue
        g = P[img]
        g = g[g.conf >= 0.25].sort_values("conf", ascending=False, kind="stable")
        if not len(g):
            continue
        b = g[["xc", "yc", "w", "h"]].to_numpy()
        iou = box_iou(gb, xywh2xyxy(b))
        used = set()
        for j in range(len(b)):
            best, bi = 0.5, None
            for i in range(len(gc)):
                if i not in used and iou[i, j] >= best:
                    best, bi = iou[i, j], i
            if bi is not None:
                used.add(bi)
                ga = (gb[bi, 2] - gb[bi, 0]) * (gb[bi, 3] - gb[bi, 1])
                rows.append(dict(img=ii, gt=bi, cls=int(g["cls"].iloc[j]), conf=g["conf"].iloc[j],
                                 log_area=np.log(b[j, 2] * b[j, 3]), log_aspect=np.log(b[j, 2] / b[j, 3]),
                                 y=np.log(b[j, 2] * b[j, 3] / ga)))
    return pd.DataFrame(rows)


def cv_r2(df, k=5, seed=0):
    rng = np.random.default_rng(seed)
    folds = rng.integers(0, k, df.img.max() + 1)[df.img.to_numpy()]
    X = np.column_stack([np.eye(NC)[df.cls.to_numpy()], df.log_area, df.log_aspect, df.conf])
    y = df.y.to_numpy()
    pred = np.zeros_like(y)
    for f in range(k):
        tr, te = folds != f, folds == f
        coef, *_ = np.linalg.lstsq(np.column_stack([X[tr], np.ones(tr.sum())]), y[tr], rcond=None)
        pred[te] = np.column_stack([X[te], np.ones(te.sum())]) @ coef
    r2 = 1 - ((y - pred) ** 2).sum() / ((y - y.mean()) ** 2).sum()
    q = lambda v: (np.quantile(v, 0.75) - np.quantile(v, 0.25)) / 2 * 100  # noqa: E731  yari-IQR, log~%
    return r2, q(y), q(y - pred)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    gt = load_gt(ROOT / "dataset" / "labels" / "test")
    imgs = sorted(gt)
    runs = {f"rastgele_s{s}": ROOT / "runs_random" / f"yolov8n_rnd010_s{s}" for s in (0, 1, 2)}
    runs.update({f"orijinal_s{s}": ROOT / "runs_main" / f"yolov8n_m000_s{s}" for s in (0, 1)})
    D, rows = {}, []
    for name, rd in runs.items():
        D[name] = pairs(rd, gt, imgs)
        r2, before, after = cv_r2(D[name])
        rows.append(dict(model=name, n=len(D[name]), cv_R2=r2, yari_iqr_once=before, yari_iqr_sonra=after))
        print(rows[-1], flush=True)
    pd.DataFrame(rows).to_csv(OUT / "sapma_tahmin.csv", index=False)

    # ayni kus (goruntu, gercek kutu) icin seed'ler arasi sapma korelasyonu
    for cond, names in (("rastgele", ["rastgele_s0", "rastgele_s1", "rastgele_s2"]),
                        ("orijinal", ["orijinal_s0", "orijinal_s1"])):
        m = None
        for n in names:
            t = D[n].set_index(["img", "gt"])["y"].rename(n)
            m = t.to_frame() if m is None else m.join(t, how="inner")
        c = m.corr().values[np.triu_indices(len(names), 1)]
        print(f"{cond}: ayni kusta seed'ler arasi sapma korelasyonu {np.round(c, 2)} (n={len(m)})")


if __name__ == "__main__":
    main()
