"""Bolum 3.6 'yayilimin ne kadari gercek tur farki' hesabinin kontrolu (iki seed ortalamasinin guvenilirligi).

    python analiz/guvenilirlik.py
"""
import numpy as np
from scipy import stats

from tur_bolumu_sayilar import S

a = (S[(0, -1)] + S[(0, 1)]) / 2          # seed 0 genel egim (25 tur)
b = (S[(1, -1)] + S[(1, 1)]) / 2          # seed 1
rs, rp = stats.spearmanr(a, b)[0], stats.pearsonr(a, b)[0]
obs, noise = np.var((a + b) / 2, ddof=1), np.var(a - b, ddof=1) / 4
icc = 2 * np.cov(a, b)[0, 1] / (np.var(a, ddof=1) + np.var(b, ddof=1))
print(f"Spearman rho {rs:.3f} -> Spearman-Brown {2 * rs / (1 + rs):.3f}")
print(f"Pearson r    {rp:.3f} -> Spearman-Brown {2 * rp / (1 + rp):.3f}")
print(f"tek seed ICC {icc:.3f} -> Spearman-Brown {2 * icc / (1 + icc):.3f}")
print(f"varyans yontemi (makaledeki): 1 - var(gurultu)/var(ort) = {1 - noise / obs:.3f}")
