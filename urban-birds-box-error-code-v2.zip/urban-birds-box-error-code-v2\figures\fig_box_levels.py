"""Ornek sekil: ayni fotografta -10%, 0% ve +10% egitim kutusu (alan k = 1 + p/100, kenar sqrt(k), merkez sabit;
04_make_margins.py ile ayni tanim). Fotograflar CC0 (iNaturalist). Yalniz figures/'a yazar."""
from pathlib import Path
import math
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from matplotlib.lines import Line2D
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
OUT = Path(__file__).resolve().parent
plt.rcParams.update({"font.family": ["Arial", "Liberation Sans", "DejaVu Sans"], "pdf.fonttype": 42})
SEL = [("test/00_404317646_742468798", "Columba livia"),
       ("val/04_403533690_741066516", "Corvus cornix"),
       ("train/09_404195477_742238826", "Erithacus rubecula"),
       ("train/14_396940550_727972322", "Aegithalos caudatus"),
       ("train/20_400414654_734788908", "Garrulus glandarius"),
       ("train/24_402575691_739050744", "Myiopsitta monachus")]
LEV = [(-10, "#0072B2", (0, (3, 1.5)), "−10%"), (0, "#F0E442", (0, (3, 1.5)), "0% (tight)"), (10, "#D55E00", (0, (3, 1.5)), "+10%")]
MM = 1 / 25.4


def box(x, y, w, h, p):
    s = math.sqrt(1 + p / 100)
    x1, x2 = max(0, x - w * s / 2), min(1, x + w * s / 2)
    y1, y2 = max(0, y - h * s / 2), min(1, y + h * s / 2)
    return x1, y1, x2, y2


fig, axes = plt.subplots(3, 2, figsize=(85 * MM, 108 * MM))
fig.subplots_adjust(left=0.005, right=0.995, top=0.965, bottom=0.06, wspace=0.03, hspace=0.15)
axes = axes.ravel()
for ax, (s, name) in zip(axes, SEL):
    im = Image.open(ROOT / "dataset" / "images" / f"{s}.jpg").convert("RGB")
    W, H = im.size
    _, x, y, w, h = map(float, open(ROOT / "dataset" / "labels" / f"{s}.txt").readline().split())
    # kirpma: kutunun etrafinda, en buyuk kutunun 1.5 kati, en-boy 4:3
    cw = max(w * W, h * H * 4 / 3) * 1.3
    ch = cw * 3 / 4
    cx, cy = x * W, y * H
    l, t = max(0, min(W - cw, cx - cw / 2)), max(0, min(H - ch, cy - ch / 2))
    r, b = min(W, l + cw), min(H, t + ch)
    ax.imshow(im.crop((int(l), int(t), int(r), int(b))))
    for p, col, ls, _ in LEV:
        x1, y1, x2, y2 = box(x, y, w, h, p)
        ax.add_patch(Rectangle((x1 * W - l, y1 * H - t), (x2 - x1) * W, (y2 - y1) * H,
                               fill=False, ec=col, lw=0.5, ls=(0, (3, 1.2))))
    ax.set_title(name, fontsize=7.5, style="italic", pad=1.5)
    ax.set_axis_off()
handles = [Line2D([], [], color=c, lw=1.4, ls=ls, label=lab) for _, c, ls, lab in LEV]
fig.legend(handles=handles, loc="lower center", ncol=3, frameon=False, fontsize=8, bbox_to_anchor=(0.5, 0.0),
           title=None, handletextpad=0.5, columnspacing=1.2, borderaxespad=0.1)
for ext in ("png", "pdf"):
    fig.savefig(OUT / f"sekil_kutu_seviyeleri_6_tek_sutun_yakin.{ext}", dpi=600, bbox_inches="tight", pad_inches=0.01)
print("yazildi")
