"""kutu_testi.html'den inen kutular_<ad>.json dosyalarini sikiz test kutulariyla karsilastirir (etiket_testi/analiz.py ile ayni kurallar).
    python etiket_testi/arkadas/analiz_arkadas.py etiket_testi/arkadas/sonuclar/kutular_<ad>.json
SALT OKUR; yalniz etiket_testi/arkadas/sonuclar/ altina <ad>_karsilastirma.csv yazar."""
import json, sys
from pathlib import Path
import numpy as np, pandas as pd
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from analiz import tight_boxes, iou, ROOT  # noqa: E402

def run(f):
    f = Path(f); d0 = json.loads(f.read_text(encoding="utf-8")); drawn = d0["boxes"]
    rows, missed, extra = [], 0, 0
    for name, boxes in drawn.items():
        g = tight_boxes(name); u = np.array(boxes, dtype=float).reshape(-1, 4)
        pairs = sorted(((iou(u[j], g[i]), i, j) for i in range(len(g)) for j in range(len(u))), reverse=True)
        gi, uj = set(), set()
        for v, i, j in pairs:
            if v < 0.3 or i in gi or j in uj: continue
            gi.add(i); uj.add(j)
            gw, gh = g[i, 2] - g[i, 0], g[i, 3] - g[i, 1]; uw, uh = u[j, 2] - u[j, 0], u[j, 3] - u[j, 1]
            rows.append(dict(image=name, species=name.split("_")[0], iou=v, area_ratio=uw * uh / (gw * gh), w_ratio=uw / gw, h_ratio=uh / gh))
        missed += len(g) - len(gi); extra += len(u) - len(uj)
    d = pd.DataFrame(rows); d.to_csv(f.parent / (f.stem.replace("boxes_", "") + "_comparison.csv"), index=False)
    q = lambda s: f"{s.median():.3f} (IQR {s.quantile(.25):.3f}-{s.quantile(.75):.3f})"
    print(f"Etiketleyici: {d0.get('annotator')}  goruntu: {len(drawn)}, eslesen kus: {len(d)}, atlanan: {missed}, fazla kutu: {extra}")
    print("Alan orani (el/sikiz):", q(d.area_ratio)); print("Genislik orani:", q(d.w_ratio)); print("Yukseklik orani:", q(d.h_ratio)); print("IoU:", q(d.iou))
    print(f"Ortalama alan orani: {d.area_ratio.mean():.3f}; |sapma| <=%3: %{100*(d.area_ratio.sub(1).abs()<=0.03).mean():.0f}; <=%5: %{100*(d.area_ratio.sub(1).abs()<=0.05).mean():.0f}; >%10: {(d.area_ratio.sub(1).abs()>0.10).sum()}")
    p = 100 * (d.area_ratio.median() - 1)
    res = pd.read_csv(ROOT / "results_main" / "results.csv")
    res = res[(res.model == "yolov8n") & (res.protocol == "tight") & (res.class_id.astype(str) == "all")]
    res = res[pd.to_numeric(res.margin, errors="coerce").notna()]; res["margin"] = res.margin.astype(float)
    ap = res.groupby("margin").AP50_95.mean(); lvl = float(np.clip(round(p), -10, 10))
    print(f"Medyan alan sapmasi {p:+.1f}% -> en yakin seviye {lvl:+.0f}%: YOLOv8n AP50-95 kaybi {100*(ap[lvl]-ap[0.0]):+.1f} puan")
    print(d.sort_values("area_ratio")[["image","area_ratio","iou"]].iloc[[0,1,-2,-1]].to_string(index=False))

if __name__ == "__main__":
    for f in sys.argv[1:]: run(f)
