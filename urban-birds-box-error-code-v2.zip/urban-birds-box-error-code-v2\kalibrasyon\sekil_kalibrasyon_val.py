"""Kalibrasyon sekli (taslak): kalibrasyon goruntu sayisina gore AP50-95 kaybi, hata seviyeleri |p| >= 3.
Stil analiz/fig_sonuclar.py ile ayni. Tek sutun, 90 x 62 mm. Yalniz kalibrasyon/cikti_val/'ya yazar.

    python kalibrasyon/sekil_kalibrasyon_val.py
"""
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

HERE = Path(__file__).resolve().parent
MM = 1 / 25.4
NAVY, ORANGE, GREY, AXC, GRIDC = "#1F4F78", "#C45912", "#808080", "#6B6B6B", "#E3E3E3"
plt.rcParams.update({
    "font.family": ["Arial", "Liberation Sans", "DejaVu Sans"], "pdf.fonttype": 42, "axes.edgecolor": AXC, "axes.linewidth": 0.8,
    "xtick.color": AXC, "ytick.color": AXC, "xtick.major.width": 0.8, "ytick.major.width": 0.8,
    "xtick.major.size": 3, "ytick.major.size": 3, "xtick.labelcolor": "#333333", "ytick.labelcolor": "#333333",
    "axes.labelcolor": "#222222", "lines.solid_capstyle": "round"})

d = pd.read_csv(HERE / "cikti_val" / "kalibrasyon_val_sonuclari.csv")
for c in ("ap_base", "ap_raw", "ap_cal", "ap_orc"):
    d[c] *= 100
d = d[(d.margin.abs() >= 3) & d.n.isin([5, 10, 20, 50, 100])]   # eski sekille ayni n kumesi
d["L_raw"], d["L_cal"], d["L_orc"] = d.ap_raw - d.ap_base, d.ap_cal - d.ap_base, d.ap_orc - d.ap_base

FS = 7
fig, ax = plt.subplots(figsize=(90 * MM, 62 * MM))
fig.subplots_adjust(left=0.15, right=0.97, bottom=0.17, top=0.97)
for model, col, mk, lab in (("yolov8n", NAVY, "o", "YOLOv8n"), ("yolov10n", ORANGE, "s", "YOLOv10n")):
    g = d[d.model == model].groupby("n")
    n = np.array(sorted(d.n.unique()))
    cal, lo = g.L_cal.mean().values, g.L_cal.quantile(0.05).values
    ax.fill_between(n, lo, cal, color=col, alpha=0.10, lw=0)
    ax.plot(n, cal, "-", color=col, marker=mk, ms=3, lw=1.1, mfc=col, mec="white", mew=0.4,
            label=f"{lab}, calibrated")
    ax.axhline(g.L_raw.mean().mean(), color=col, lw=0.9, dashes=(4, 2))
    ax.axhline(g.L_orc.mean().mean(), color=col, lw=0.6, dashes=(1, 1.5))
ax.text(105, d.L_raw.mean() + 0.25, "Uncorrected", fontsize=6, ha="right", va="bottom", color="#333333")
ax.text(105, d.L_orc.mean() - 0.12, "True k (upper bound)", fontsize=6, ha="right", va="top", color="#333333")
ax.axhline(0, color=AXC, lw=0.5)
ax.set_xscale("log")
ax.set_xticks([5, 10, 20, 50, 100])
ax.set_xticklabels(["5", "10", "20", "50", "100"])
ax.set_xlim(4.3, 116)
ax.set_xlabel("Calibration images with tight boxes", fontsize=FS)
ax.set_ylabel("ΔAP50-95 vs. original boxes (pp)", fontsize=FS)
ax.yaxis.grid(True, color=GRIDC, lw=0.5)
ax.set_axisbelow(True)
ax.tick_params(labelsize=FS)
for s in ("top", "right"):
    ax.spines[s].set_visible(False)
from matplotlib.lines import Line2D
ax.legend(handles=[Line2D([], [], color=NAVY, marker="o", ms=3, lw=1.1, mec="white", mew=0.4, label="YOLOv8n"),
                   Line2D([], [], color=ORANGE, marker="s", ms=3, lw=1.1, mec="white", mew=0.4, label="YOLOv10n"),
                   Line2D([], [], color=GREY, lw=1.1, label="Calibrated (mean; band: 5th percentile)")],
          frameon=False, fontsize=6, loc="center right", bbox_to_anchor=(1.0, 0.45))
for ext in ("pdf", "png"):
    fig.savefig(HERE / "cikti_val" / f"sekil_kalibrasyon_val.{ext}", dpi=600)
print("yazildi:", HERE / "cikti_val" / "sekil_kalibrasyon_val.pdf")
