"""Bolum 3.7 icin sayilar: YOLOv8n (2 seed ort.) ile YOLOv10n (1 seed) karsilastirmasi.
Tum AP'ler results_main/results.csv (sıkı test, Ultralytics val); geri olcekleme shrink_back.csv,
kutu orani box_ratio.csv'den.

    python analiz/mimari_sayilar.py
"""
import csv
from pathlib import Path

import numpy as np
from scipy import stats

ROOT = Path(__file__).resolve().parent.parent
L = list(range(-10, 11))
C = range(25)
R = list(csv.DictReader(open(ROOT / "results_main/results.csv", encoding="utf-8")))


def get(model, proto="tight", col="AP50_95"):
    out = {}
    for r in R:
        if r["model"] == model and r["protocol"] == proto:
            out[(int(float(r["margin"])), int(r["seed"]), r["class_id"])] = 100 * float(r[col])
    return out


v8, v10 = get("yolov8n"), get("yolov10n")
sp8 = {m: np.array([(v8[(m, 0, str(c))] + v8[(m, 1, str(c))]) / 2 for c in C]) for m in L}
sp8s = {s: {m: np.array([v8[(m, s, str(c))] for c in C]) for m in L} for s in (0, 1)}
sp10 = {m: np.array([v10[(m, 0, str(c))] for c in C]) for m in L}
all8 = {m: (v8[(m, 0, "all")] + v8[(m, 1, "all")]) / 2 for m in L}
all10 = {m: v10[(m, 0, "all")] for m in L}


def holm(p):
    p = np.asarray(p)
    o = np.argsort(p)
    adj = np.minimum(1, np.maximum.accumulate((len(p) - np.arange(len(p))) * p[o]))
    out = np.empty_like(adj)
    out[o] = adj
    return out


print("== Genel AP50-95 (tum turler)")
print(f"  AP0: v8n {all8[0] / 100:.3f}, v10n {all10[0] / 100:.3f}")
for m in (-10, -5, -3, -2, -1, 1, 2, 3, 5, 10):
    print(f"  {m:+d}%: dAP v8n {all8[m] - all8[0]:+.1f}  v10n {all10[m] - all10[0]:+.1f}   (v10n AP {all10[m] / 100:.3f})")
d8 = np.array([all8[m] - all8[0] for m in L if m])
d10 = np.array([all10[m] - all10[0] for m in L if m])
print(f"  ortalama kayip egrileri arasi fark: ort |fark| {np.abs(d8 - d10).mean():.2f}, en buyuk {np.abs(d8 - d10).max():.2f} puan")
print("  egri sekli Pearson r:", f"{stats.pearsonr(d8, d10)[0]:.3f}")

print("\n== v10n: tur bazinda Wilcoxon (her seviye vs %0), Holm")
p = [stats.wilcoxon(sp10[m], sp10[0]).pvalue for m in L if m]
ph = holm(p)
lv = [m for m in L if m]
print("  anlamli seviye sayisi:", int((ph < 0.05).sum()), "/ 20; anlamsizlar:",
      [f"{m:+d} (p={q:.2f})" for m, q in zip(lv, ph) if q >= 0.05])
print("  dusen tur sayisi (-10/+10):", int((sp10[-10] < sp10[0]).sum()), int((sp10[10] < sp10[0]).sum()))
fr = stats.friedmanchisquare(*[sp10[m] for m in L])
W = fr.statistic / (25 * (len(L) - 1))
print(f"  Friedman chi2={fr.statistic:.1f}, p={fr.pvalue:.1e}, Kendall W={W:.2f}")

print("\n== Tur duzeyi tutarlilik: Spearman rho (v8n seed ort. dAP vs v10n dAP) ve seed gurultusu referansi")
rows = []
for m in lv:
    a = sp8[m] - sp8[0]
    b = sp10[m] - sp10[0]
    r_arch = stats.spearmanr(a, b)[0]
    r_seed = stats.spearmanr(sp8s[0][m] - sp8s[0][0], sp8s[1][m] - sp8s[1][0])[0]
    rows.append((m, r_arch, r_seed))
    print(f"  {m:+3d}%: mimari rho={r_arch:+.2f}   (v8n seed0 vs seed1 rho={r_seed:+.2f})")
ra = np.array([r[1] for r in rows])
rs = np.array([r[2] for r in rows])
big = np.array([abs(r[0]) >= 5 for r in rows])
print(f"  |p|>=5: mimari rho {ra[big].min():.2f}-{ra[big].max():.2f} (ort {ra[big].mean():.2f}); "
      f"seed rho {rs[big].min():.2f}-{rs[big].max():.2f} (ort {rs[big].mean():.2f})")
print(f"  |p|<=4: mimari rho {ra[~big].min():.2f}-{ra[~big].max():.2f}; seed rho {rs[~big].min():.2f}-{rs[~big].max():.2f}")


def slope(sp, side):
    x = np.arange(1, 11)
    y = np.array([sp[side * k] for k in x])            # 10 x 25
    return -np.polyfit(x, y, 1)[0]


s8 = (slope(sp8, -1) + slope(sp8, 1)) / 2
s10 = (slope(sp10, -1) + slope(sp10, 1)) / 2
s8a = (slope(sp8s[0], -1) + slope(sp8s[0], 1)) / 2
s8b = (slope(sp8s[1], -1) + slope(sp8s[1], 1)) / 2
print("\n== Egim tabanli tur duyarliligi (Bolum 3.6 yontemi)")
print(f"  v10n egim: daraltma ort {slope(sp10, -1).mean():.2f}, genisletme ort {slope(sp10, 1).mean():.2f} puan / %1")
r, pv = stats.spearmanr(s8, s10)
print(f"  v8n (seed ort.) vs v10n: rho={r:.2f}, p={pv:.3f}")
for nm, x in (("seed0", s8a), ("seed1", s8b)):
    print(f"  v8n {nm} vs v10n: rho={stats.spearmanr(x, s10)[0]:.2f}")
print(f"  referans v8n seed0 vs seed1: rho={stats.spearmanr(s8a, s8b)[0]:.2f}")
names = {int(r_["class_id"]): r_["class_name"] for r_ in R if r_["class_id"] != "all"}
o10 = np.argsort(-s10)
print("  v10n en duyarli 3:", [names[i] for i in o10[:3]], "| en dayanikli 3:", [names[i] for i in o10[::-1][:3]])
print("  v10n duyarlilik vs temel AP:", "rho=%.2f p=%.3f" % stats.spearmanr(s10, sp10[0]))

print("\n== Geri olcekleme (shrink_back.csv, tahmin tabanli AP)")
sb = list(csv.DictReader(open(ROOT / "results_main/shrink_back.csv", encoding="utf-8")))
for model, seeds in (("yolov8n", (0, 1)), ("yolov10n", (0,))):
    g = {}
    for r_ in sb:
        if r_["model"] == model and int(r_["seed"]) in seeds:
            g.setdefault((int(float(r_["margin"])), r_["rescale"]), []).append(100 * float(r_["AP50_95"]))
    base = np.mean(g[(0, "none")])
    raw = [np.mean(g[(m, "none")]) - base for m in lv]
    res = [np.mean(g[(m, "rescaled")]) - base for m in lv]
    print(f"  {model}: ham kayip {min(raw):+.1f}..{max(raw):+.1f}; geri olceklenmis {min(res):+.1f}..{max(res):+.1f} "
          f"(-10: {res[0]:+.1f}, +10: {res[-1]:+.1f})")

print("\n== Kutu orani (box_ratio.csv, ortanca tahmin/gercek alan)")
br = list(csv.DictReader(open(ROOT / "results_main/box_ratio.csv", encoding="utf-8")))
for model in ("yolov8n", "yolov10n"):
    dev = []
    for r_ in br:
        if r_["model"] == model and r_["class_id"] == "all" and r_["condition"] in ("mn010", "m000", "m010"):
            print(f"  {model} {r_['condition']} s{r_['seed']}: k={r_['k']} ortanca oran={float(r_['median_ratio']):.3f}")
    for r_ in br:
        if r_["model"] == model and r_["class_id"] == "all" and r_["condition"].startswith("m"):
            dev.append(abs(float(r_["median_ratio"]) - float(r_["k"])))
    print(f"  {model}: |ortanca oran - k| en fazla {max(dev):.3f}")
