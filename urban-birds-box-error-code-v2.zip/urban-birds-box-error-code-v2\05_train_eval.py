"""
Step 5 - Train one model per (margin, seed) and evaluate it on the TEST split.

Runs are sequential and resumable: a finished run (row already in the results CSV) is
skipped, an interrupted run continues from its last.pt.

Every model is evaluated with three protocols on the test images:
    tight     - original tight test boxes, per class            (main result)
    agnostic  - original tight test boxes, single_cls=True      (pure localisation;
                also per species: class_id = species of the test images)
    expanded  - test boxes changed with the SAME margin as train (enlarged for p > 0,
                shrunk for p < 0; protocol used in the literature)

Output:
    <runs>/m010_s0/...                      Ultralytics run folders
    <results>                               one row per run x protocol x class
                                            (class = "all" for the mean)
    counts.csv (next to <results>)          per-image bird-count error on test
                                            (all / single bird / 2-6 birds / per species)
    confusion.csv (next to <results>)       species confusion on test (conf >= --count-conf,
                                            IoU >= 0.5); true/pred "background" = missed bird /
                                            false box
    <runs>/<run>/test_predictions.csv.gz    every test prediction (conf >= 0.001, normalised
                                            xywh) for image-level bootstrap / paired tests

Example (pilot):
    python 05_train_eval.py --margins-dir pilot/datasets_margin --margins 0 10 25 50 ^
        --seeds 0 1 --runs pilot/runs --results pilot/results.csv
"""
import argparse
import csv
import importlib.util
import os
import shutil
from pathlib import Path

from common import IMG_EXTS, ROOT, margin_name, read_yolo_labels, write_yolo_labels

_spec = importlib.util.spec_from_file_location("make_margins", ROOT / "04_make_margins.py")
make_margins = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(make_margins)

FIELDS = ["model", "margin", "seed", "protocol", "class_id", "class_name",
          "AP50", "AP75", "AP50_95", "precision", "recall", "epochs_run"]


def done_runs(results):
    if not Path(results).exists():
        return set()
    with open(results, encoding="utf-8") as f:
        return {(r["model"], float(r["margin"]), int(r["seed"])) for r in csv.DictReader(f)}


def run_state(last):
    """'new' (no checkpoint), 'resume' (interrupted) or 'done' (training finished:
    Ultralytics strips the optimizer and sets epoch=-1 in last.pt at the end)."""
    if not last.exists():
        return "new"
    import torch
    ckpt = torch.load(last, map_location="cpu", weights_only=False)
    return "done" if ckpt.get("epoch", -1) == -1 else "resume"


def test_images(mdir):
    """Test images of a margin dataset (skips the shared .npy cache files, see cache_npy.py)."""
    return sorted(p for p in (mdir / "images" / "test").glob("*") if p.suffix.lower() in IMG_EXTS)


def expanded_test_yaml(mdir, m, cache_root):
    """Dataset whose test labels are enlarged by m% (images hard-linked)."""
    dst = Path(cache_root) / margin_name(m)
    yaml = dst / "data.yaml"
    if yaml.exists():
        return yaml
    for img in test_images(mdir):
        make_margins.link_or_copy(img, dst / "images" / "test" / img.name)
        boxes = read_yolo_labels(mdir / "labels" / "test" / f"{img.stem}.txt")
        if m != 0:
            boxes = [(c, *make_margins.expand_box(xc, yc, w, h, m)) for c, xc, yc, w, h in boxes]
        write_yolo_labels(dst / "labels" / "test" / f"{img.stem}.txt", boxes)
    names = [l for l in (mdir / "data.yaml").read_text(encoding="utf-8").splitlines()
             if l.startswith("names:") or l.startswith("  ")]
    yaml.write_text("\n".join([f"path: {dst.resolve().as_posix()}", "train: images/test",
                               "val: images/test", "test: images/test", *names]) + "\n",
                    encoding="utf-8")
    return yaml


def species_test_yamls(mdir, cache_root):
    """One data.yaml per species whose test split = that species' test images (tight boxes),
    for the per-species class-agnostic AP. Image names start with the class id (step 3)."""
    dst = Path(cache_root) / mdir.name
    names = [l for l in (mdir / "data.yaml").read_text(encoding="utf-8").splitlines()
             if l.startswith("names:") or l.startswith("  ")]
    out = {}
    imgs = test_images(mdir)
    for cid in sorted({p.name[:2] for p in imgs}):
        lst, yaml = dst / f"test_{cid}.txt", dst / f"test_{cid}.yaml"
        if not yaml.exists():
            dst.mkdir(parents=True, exist_ok=True)
            lst.write_text("\n".join(p.resolve().as_posix() for p in imgs if p.name[:2] == cid) + "\n",
                           encoding="utf-8")
            yaml.write_text("\n".join([f"path: {mdir.resolve().as_posix()}", "train: images/test",
                                       "val: images/test", f"test: {lst.resolve().as_posix()}",
                                       *names]) + "\n", encoding="utf-8")
        out[int(cid)] = yaml
    return out


def metric_rows(metrics, base, protocol, epochs):
    box = metrics.box
    rows = [dict(base, protocol=protocol, class_id="all", class_name="all",
                 AP50=box.map50, AP75=box.map75, AP50_95=box.map,
                 precision=box.mp, recall=box.mr, epochs_run=epochs)]
    if protocol != "agnostic":
        for i, c in enumerate(box.ap_class_index):
            p, r, ap50, ap = box.class_result(i)
            rows.append(dict(base, protocol=protocol, class_id=int(c),
                             class_name=metrics.names[int(c)], AP50=ap50,
                             AP75=box.all_ap[i, 5], AP50_95=ap,
                             precision=p, recall=r, epochs_run=epochs))
    return rows


COUNT_FIELDS = ["model", "margin", "seed", "group", "n_images", "MAE", "mean_error",
                "exact_rate", "undercount_rate"]
CONF_FIELDS = ["model", "margin", "seed", "true", "pred", "n"]


def iou_xywh(a, b):
    ax1, ay1, ax2, ay2 = a[0] - a[2] / 2, a[1] - a[3] / 2, a[0] + a[2] / 2, a[1] + a[3] / 2
    bx1, by1, bx2, by2 = b[0] - b[2] / 2, b[1] - b[3] / 2, b[0] + b[2] / 2, b[1] + b[3] / 2
    i = max(0, min(ax2, bx2) - max(ax1, bx1)) * max(0, min(ay2, by2) - max(ay1, by1))
    return i / (a[2] * a[3] + b[2] * b[3] - i + 1e-12)


def match_species(gt, pred, thr=0.5):
    """Greedy class-agnostic matching (highest confidence first, IoU >= thr).
    gt: [(cls, xc, yc, w, h)], pred: [(cls, conf, xc, yc, w, h)], normalised.
    Returns (true, pred) pairs; unmatched -> 'background'."""
    pairs, used = [], set()
    for c, _, *pb in sorted(pred, key=lambda p: -p[1]):
        best, bi = thr, None
        for i, (gc, *gb) in enumerate(gt):
            if i not in used and iou_xywh(pb, gb) >= best:
                best, bi = iou_xywh(pb, gb), i
        if bi is None:
            pairs.append(("background", c))
        else:
            used.add(bi)
            pairs.append((gt[bi][0], c))
    pairs += [(g[0], "background") for i, g in enumerate(gt) if i not in used]
    return pairs


def count_rows(model, mdir, base, args, pred_file=None):
    """Per-image bird counts on the test split (class-agnostic) vs the tight labels.
    group: all / single (1 bird) / multi (2-6 birds; flocks >6 were removed in review).
    Also returns the species confusion counts from the same predictions.
    Prediction runs at conf 0.001 (all boxes go to pred_file); counts and confusion use
    only boxes with conf >= --count-conf."""
    import gzip
    from collections import Counter
    imgs = test_images(mdir)
    conf = Counter()
    errs = {"all": [], "single": [], "multi": []}  # + "class_XX" (species of the image)
    pf = gzip.open(pred_file, "wt", newline="", encoding="utf-8") if pred_file else None
    pw = csv.writer(pf) if pf else None
    if pw:
        pw.writerow(["image", "cls", "conf", "xc", "yc", "w", "h"])
    for i in range(0, len(imgs), args.batch):
        chunk = imgs[i:i + args.batch]
        preds = model.predict([str(p) for p in chunk], conf=0.001, imgsz=args.imgsz,
                              device=args.device, verbose=False)
        for img, pr in zip(chunk, preds):
            gtb = read_yolo_labels(mdir / "labels" / "test" / f"{img.stem}.txt")
            allb = [(int(c), float(s), *map(float, b)) for c, s, b in
                    zip(pr.boxes.cls.tolist(), pr.boxes.conf.tolist(), pr.boxes.xywhn.tolist())]
            if pw:
                pw.writerows([img.name, c, round(s, 5), *(round(v, 6) for v in b)]
                             for c, s, *b in allb)
            pb = [p for p in allb if p[1] >= args.count_conf]
            gt = len(gtb)
            e = len(pb) - gt
            conf.update(match_species(gtb, pb))
            errs["all"].append(e)
            errs["single" if gt <= 1 else "multi"].append(e)
            # image names start with the class id ("03_<obs>_<photo>.jpg", step 3)
            errs.setdefault(f"class_{img.name[:2]}", []).append(e)
    rows = []
    for g, es in errs.items():
        n = len(es)
        rows.append(dict(base, group=g, n_images=n,
                         MAE=sum(abs(e) for e in es) / n if n else "",
                         mean_error=sum(es) / n if n else "",
                         exact_rate=sum(e == 0 for e in es) / n if n else "",
                         undercount_rate=sum(e < 0 for e in es) / n if n else ""))
    if pf:
        pf.close()
    conf_rows = [dict(base, true=t, pred=p, n=k) for (t, p), k in sorted(conf.items(), key=str)]
    return rows, conf_rows


def append_csv(path, fields, rows):
    new_file = not Path(path).exists()
    with open(path, "a", newline="", encoding="utf-8") as f:
        wr = csv.DictWriter(f, fieldnames=fields)
        if new_file:
            wr.writeheader()
        for r in rows:
            wr.writerow({k: (round(v, 5) if isinstance(v, float) else v) for k, v in r.items()})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--margins-dir", default="datasets_margin")
    ap.add_argument("--margins", type=float, nargs="+",
                    default=list(range(-10, 11)))  # -10, -9, ..., +10
    ap.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2])
    ap.add_argument("--model", default="yolov8n.pt")
    ap.add_argument("--runs", default="runs_margin")
    ap.add_argument("--results", default="results/results.csv")
    ap.add_argument("--epochs", type=int, default=150)
    ap.add_argument("--patience", type=int, default=30)
    ap.add_argument("--imgsz", type=int, default=640)
    ap.add_argument("--batch", type=int, default=16)
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--cache", default="disk")
    ap.add_argument("--device", default="0")
    ap.add_argument("--count-conf", type=float, default=0.25,
                    help="confidence threshold for the per-image bird count")
    args = ap.parse_args()

    # 2026-10-11: YOLOv10n eğitimleri ikinci (aynı model) bilgisayarda yapılıyor; bu dosya varsa burada atlanır.
    if "yolov10" in Path(args.model).stem and (ROOT / "V10N_ARKADASTA").exists():
        print(f"{args.model}: V10N_ARKADASTA dosyası var, bu bilgisayarda atlanıyor.")
        return

    from ultralytics import YOLO

    runs = Path(args.runs).resolve()
    Path(args.results).parent.mkdir(parents=True, exist_ok=True)
    model_tag = Path(args.model).stem
    finished = done_runs(args.results)

    for m in args.margins:
        mdir = Path(args.margins_dir) / margin_name(m)
        for seed in args.seeds:
            key = (model_tag, float(m), int(seed))
            if key in finished:
                print(f"skip {model_tag} {margin_name(m)} seed {seed} (done)")
                continue
            name = f"{model_tag}_{margin_name(m)}_s{seed}"
            state = run_state(runs / name / "weights" / "last.pt")
            if state == "resume":
                YOLO(str(runs / name / "weights" / "last.pt")).train(resume=True)
            elif state == "new":
                shutil.rmtree(runs / name, ignore_errors=True)
                YOLO(args.model).train(
                    data=str(mdir / "data.yaml"), epochs=args.epochs, patience=args.patience,
                    imgsz=args.imgsz, batch=args.batch, workers=args.workers, cache=args.cache,
                    device=args.device, seed=seed, deterministic=True, amp=True,
                    project=str(runs), name=name, exist_ok=True, plots=True, verbose=False)

            best = runs / name / "weights" / "best.pt"
            res_csv = runs / name / "results.csv"
            epochs = sum(1 for _ in open(res_csv)) - 1 if res_csv.exists() else ""
            base = dict(model=model_tag, margin=m, seed=seed)
            model = YOLO(str(best))
            rows = []
            common = dict(split="test", imgsz=args.imgsz, batch=args.batch, device=args.device,
                          workers=args.workers, plots=False, verbose=False,
                          project=str(runs / name), exist_ok=True)
            rows += metric_rows(model.val(data=str(mdir / "data.yaml"), name="test_tight", **common),
                                base, "tight", epochs)
            rows += metric_rows(model.val(data=str(mdir / "data.yaml"), single_cls=True,
                                          name="test_agnostic", **common),
                                base, "agnostic", epochs)
            for cid, yaml in species_test_yamls(mdir, Path(args.margins_dir).parent /
                                                 "test_species").items():
                r = metric_rows(model.val(data=str(yaml), single_cls=True,
                                          name="test_agnostic_species", **common),
                                base, "agnostic", epochs)[0]
                rows.append(dict(r, class_id=cid, class_name=model.names[cid]))
            exp_yaml = expanded_test_yaml(mdir, m, Path(args.margins_dir).parent / "test_expanded")
            rows += metric_rows(model.val(data=str(exp_yaml), name="test_expanded", **common),
                                base, "expanded", epochs)

            # counts first: the AP row is the "run finished" marker for resuming
            c_rows, conf_rows = count_rows(model, mdir, base, args,
                                           runs / name / "test_predictions.csv.gz")
            append_csv(Path(args.results).with_name("counts.csv"), COUNT_FIELDS, c_rows)
            append_csv(Path(args.results).with_name("confusion.csv"), CONF_FIELDS, conf_rows)
            append_csv(args.results, FIELDS, rows)
            tight = rows[0]
            print(f"{name}: tight AP50={tight['AP50']:.3f} AP50-95={tight['AP50_95']:.3f}")


if __name__ == "__main__":
    os.environ.setdefault("PYTHONIOENCODING", "utf-8")
    main()
