"""Geri olcekleme analizi Ultralytics dogrulama aracinin icinde (Bolum 3.4, 3.5, 3.7).

Tahmin kutulari NMS'ten sonra, AP hesaplanmadan once merkezleri korunarak kenarlari `factor` ile olceklenir;
geri kalan her sey 05_train_eval.py'deki sıkı test degerlendirmesiyle aynidir (split=test, imgsz 640,
batch 16, rect). factor = 1 iken sonuc results.csv'deki tight satiriyla birebir ayni olmalidir.

    python analiz/val_olcekle.py --check                     # birkac modelde factor=1 == results.csv
    python analiz/val_olcekle.py                             # tum kosular -> results_main/shrink_back_val.csv
"""
import argparse
import csv
import math
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from common import margin_from_name  # noqa: E402

OUT = ROOT / "results_main" / "shrink_back_val.csv"
FIELDS = ["model", "margin", "seed", "rescale", "factor", "AP50", "AP75", "AP50_95"]
RANDOM_FACTORS = [0.96, 0.97, 0.98, 0.99, 1.01, 1.02, 1.03, 1.04]


def scaled_validator(factor):
    from ultralytics.models.yolo.detect.val import DetectionValidator

    class ScaledValidator(DetectionValidator):
        def _prepare_pred(self, pred):
            pred = super()._prepare_pred(pred)
            if factor != 1.0 and len(pred["bboxes"]):
                b = pred["bboxes"].clone()
                c = (b[:, :2] + b[:, 2:]) / 2
                h = (b[:, 2:] - b[:, :2]) / 2 * factor
                pred["bboxes"] = __import__("torch").cat([c - h, c + h], 1)
            return pred

    return ScaledValidator


def evaluate(run_dir, data_yaml, factor):
    from ultralytics import YOLO
    m = YOLO(str(run_dir / "weights" / "best.pt"))
    r = m.val(validator=scaled_validator(factor), data=str(data_yaml), split="test", imgsz=640, batch=16,
              device="0", workers=4, plots=False, verbose=False,
              project=str(ROOT / "runs" / "val_olcekle"), name=run_dir.name, exist_ok=True)
    return dict(AP50=round(float(r.box.map50), 5), AP75=round(float(r.box.map75), 5),
                AP50_95=round(float(r.box.map), 5))


def reference():
    ref = {}
    for f in (ROOT / "results_main/results.csv", ROOT / "results_random/results.csv"):
        for r in csv.DictReader(open(f, encoding="utf-8")):
            if r["protocol"] == "tight" and r["class_id"] == "all":
                ref[(r["model"], r["margin"].replace(".0", "") if "rnd" not in r["margin"] else r["margin"],
                     int(r["seed"]))] = float(r["AP50_95"])
    return ref


def jobs():
    data = ROOT / "datasets_margin" / "m000" / "data.yaml"   # test kutulari tum seviyelerde ayni (sıkı)
    out = []
    for run in sorted((ROOT / "runs_main").iterdir()):
        mm = re.match(r"(yolov8n|yolov10n)_(mn?\d{3})_s(\d+)$", run.name)
        if not mm or not (run / "weights" / "best.pt").exists():
            continue
        margin = margin_from_name(mm.group(2))
        base = dict(model=mm.group(1), margin=int(margin), seed=int(mm.group(3)))
        if margin != 0:
            out.append((run, data, dict(base, rescale="rescaled", factor=round(1 / math.sqrt(1 + margin / 100), 6))))
    for run in sorted((ROOT / "runs_random").glob("yolov8n_rnd010_s*")):
        base = dict(model="yolov8n", margin="rnd010", seed=int(run.name[-1]))
        for f in RANDOM_FACTORS:
            out.append((run, data, dict(base, rescale="constant", factor=f)))
    return out


def main():
    a = argparse.ArgumentParser()
    a.add_argument("--check", action="store_true")
    args = a.parse_args()
    ref = reference()
    data = ROOT / "datasets_margin" / "m000" / "data.yaml"

    if args.check:
        for name, key in (("runs_main/yolov8n_mn010_s0", ("yolov8n", "-10", 0)),
                          ("runs_main/yolov10n_m010_s0", ("yolov10n", "10", 0)),
                          ("runs_random/yolov8n_rnd010_s1", ("yolov8n", "rnd010", 1))):
            r = evaluate(ROOT / name, data, 1.0)
            print(f"{name}: factor=1 AP50-95 {r['AP50_95']:.5f}  results.csv {ref[key]:.5f}  "
                  f"{'AYNI' if abs(r['AP50_95'] - ref[key]) < 1e-5 else 'FARKLI'}", flush=True)
        return

    done = set()
    if OUT.exists():
        done = {(r["model"], r["margin"], r["seed"], r["factor"]) for r in csv.DictReader(open(OUT, encoding="utf-8"))}
    else:
        with open(OUT, "w", newline="", encoding="utf-8") as f:
            csv.DictWriter(f, FIELDS).writeheader()
    todo = [j for j in jobs() if (j[2]["model"], str(j[2]["margin"]), str(j[2]["seed"]), str(j[2]["factor"])) not in done]
    print(f"{len(todo)} degerlendirme", flush=True)
    for i, (run, yaml, row) in enumerate(todo, 1):
        row = dict(row, **evaluate(run, yaml, row["factor"]))
        with open(OUT, "a", newline="", encoding="utf-8") as f:
            csv.DictWriter(f, FIELDS).writerow(row)
        print(f"[{i}/{len(todo)}] {run.name} f={row['factor']} AP50-95={row['AP50_95']:.4f}", flush=True)


if __name__ == "__main__":
    main()
