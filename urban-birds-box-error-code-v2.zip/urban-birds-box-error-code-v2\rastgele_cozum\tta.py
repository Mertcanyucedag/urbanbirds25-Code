"""Test sirasinda veri artirma (TTA): egitim olmadan, rastgele hatali modelin kaybini azaltiyor mu?

Ultralytics dogrulama araci (results.csv ile ayni ayarlar: test, imgsz 640, batch 16, rect) once normal,
sonra augment=True (cevirme + farkli olcekler, kutular birlestirilir) ile calistirilir.
Adil karsilastirma icin orijinal kutularla egitilen modeller de ayni sekilde degerlendirilir.

SALT OKUR: model agirliklari. Dogrulama ciktilari ve sonuc yalnizca rastgele_cozum/cikti/ altina yazilir.
"""
from pathlib import Path

import pandas as pd
from ultralytics import YOLO

ROOT = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent / "cikti"
DATA = ROOT / "datasets_margin" / "m000" / "data.yaml"          # test kutulari tum kosullarda ayni (siki)
RUNS = {**{("rastgele", s): ROOT / "runs_random" / f"yolov8n_rnd010_s{s}" for s in (0, 1, 2)},
        **{("orijinal", s): ROOT / "runs_main" / f"yolov8n_m000_s{s}" for s in (0, 1)}}


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    rows = []
    for (cond, s), rd in RUNS.items():
        m = YOLO(str(rd / "weights" / "best.pt"))
        for aug in (False, True):
            r = m.val(data=str(DATA), split="test", imgsz=640, batch=16, device="0", workers=4, rect=not aug,
                      augment=aug, plots=False, verbose=False, project=str(OUT / "val"),
                      name=f"{cond}_s{s}_{'tta' if aug else 'normal'}", exist_ok=True)
            rows.append(dict(kosul=cond, seed=s, tta=aug, AP50=100 * r.box.map50, AP75=100 * r.box.map75,
                             AP50_95=100 * r.box.map))
            print(rows[-1], flush=True)
    res = pd.DataFrame(rows)
    res.to_csv(OUT / "tta_sonuclari.csv", index=False)
    print(res.groupby(["kosul", "tta"])[["AP50", "AP75", "AP50_95"]].mean().round(2))


if __name__ == "__main__":
    main()
