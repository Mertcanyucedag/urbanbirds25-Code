"""Tur duyarliligini %0'i paylasmadan olcer: her yon icin AP'nin |p|'ye gore egimi (|p| = 1..10, %0 haric).

- guvenilirlik: ayni yonde seed0 egimi ile seed1 egimi (bagimsiz egitimler) arasindaki Spearman
- rhoSE'nin temiz hali: daraltma egimi vs genisletme egimi (ortak nokta yok)
- rhoBase'in temiz hali: egim vs %0'daki AP (egim %0'i icermiyor)
Seed 1'de genisletme tarafi henuz +5'e kadar oldugu icin egimler kullanilabilir seviyelerle hesaplanir.
"""
import csv
from pathlib import Path

import numpy as np
from scipy import stats

ROOT = Path(__file__).resolve().parent.parent
R = [r for r in csv.DictReader(open(ROOT / "results_main/results.csv", encoding="utf-8"))
     if r["model"] == "yolov8n" and r["protocol"] == "tight" and r["class_id"] != "all"]
ap = {(int(float(r["margin"])), int(r["seed"]), int(r["class_id"])): 100 * float(r["AP50_95"]) for r in R}
names = {int(r["class_id"]): r["class_name"] for r in R}


def slope(seed, side, levels=range(1, 11)):
    """Turler icin AP'nin |p|'ye gore egimi (puan / %1 hata); negatif = kayip. %0 kullanilmaz."""
    ks = [k for k in levels if all((side * k, seed, c) in ap for c in range(25))]
    x = np.array(ks, float)
    y = np.array([[ap[(side * k, seed, c)] for k in ks] for c in range(25)])
    b = np.polyfit(x, y.T, 1)[0]
    return b, ks


def show(label, a, b):
    r, p = stats.spearmanr(a, b)
    print(f"   {label:62s} rho={r:+.2f}  p={p:.3f}")


print("1) Guvenilirlik: ayni yonun egimi iki bagimsiz seed'de tutarli mi?")
s0, k0 = slope(0, -1)
s1, k1 = slope(1, -1)
show(f"daraltma egimi seed0 vs seed1 (|p|={k1[0]}..{k1[-1]})", s0, s1)
e0, _ = slope(0, +1, range(1, 6))
e1, ke = slope(1, +1, range(1, 6))
show(f"genisletme egimi seed0 vs seed1 (|p|={ke[0]}..{ke[-1]}, seed1 henuz +5'e kadar)", e0, e1)

print("\n2) rhoSE'nin temiz hali (daraltma egimi vs genisletme egimi, ortak %0 yok)")
E0, _ = slope(0, +1)
show("seed0: daraltma(-1..-10) vs genisletme(+1..+10)", s0, E0)
show("capraz: daraltma seed1 vs genisletme seed0", s1, E0)
show("seed0, yalniz 1..5: daraltma vs genisletme", slope(0, -1, range(1, 6))[0], e0)
show("capraz 1..5: daraltma seed1 vs genisletme seed0", slope(1, -1, range(1, 6))[0], e0)

print("\n3) rhoBase'in temiz hali (kayip buyuklugu = -egim vs %0'daki AP)")
ap0 = {s: np.array([ap[(0, s, c)] for c in range(25)]) for s in (0, 1)}
show("seed0 daraltma egimi vs seed0 AP0", -s0, ap0[0])
show("seed0 daraltma egimi vs seed1 AP0 (bagimsiz)", -s0, ap0[1])
show("seed1 daraltma egimi vs seed0 AP0 (bagimsiz)", -s1, ap0[0])
show("iki seed ort. daraltma egimi vs iki seed ort. AP0", -(s0 + s1) / 2, (ap0[0] + ap0[1]) / 2)

print("\n4) Turler arasi egim farki gercek mi? (gurultuye gore)")
diff = s1 - s0
print(f"   daraltma egimi turler arasi sd (iki seed ort.): {((s0 + s1) / 2).std(ddof=1):.3f} puan/%  | "
      f"seed farkindan tahmini gurultu sd (ortalama icin): {diff.std(ddof=1) / 2:.3f}")
avg = (s0 + s1) / 2
o = np.argsort(avg)
print("   en duyarli 3 (iki seed ort.):", ", ".join(f"{names[i]} {avg[i]:.2f}" for i in o[:3]))
print("   en dayanikli 3:", ", ".join(f"{names[i]} {avg[i]:.2f}" for i in o[::-1][:3]))
