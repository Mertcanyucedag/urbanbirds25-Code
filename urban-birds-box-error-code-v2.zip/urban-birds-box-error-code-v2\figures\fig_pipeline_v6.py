"""Figure 1 (v6): study workflow, single column 90 mm x 175 mm (same proportions as the manuscript's
current figure). Three phases on a left rail (dataset / experiment / evaluation), seven step cards.
Muted three-tone palette, white cards, real data. All photos CC0 (iNaturalist).

    python figures/fig_pipeline_v6.py   -> figures/makale/fig_pipeline_v6.{pdf,png,tif}
"""
import csv
from collections import defaultdict
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from matplotlib.patches import Circle, FancyArrowPatch, FancyBboxPatch, Rectangle  # noqa: E402

import fig_pipeline_v4 as v4  # noqa: E402  (load/crop helpers)

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "figures" / "makale"
INK, SUB, LINE = "#1F2328", "#57606A", "#C9CED6"
PH = {"A": ("#2F5D8A", "#E3EAF2", "DATASET"),          # slate blue
      "B": ("#2A7F72", "#DFF0EC", "EXPERIMENT"),       # teal
      "C": ("#B0662B", "#F6E9DD", "EVALUATION")}       # amber
K_SHR, K_ORI, K_ENL = "#2F5D8A", "#1F2328", "#C0502E"

plt.close("all")
plt.rcParams.update({"font.family": "Arial", "font.size": 7, "pdf.fonttype": 42})
W, H = 90 / 25.4, 175 / 25.4
fig = plt.figure(figsize=(W, H))
ax = fig.add_axes([0, 0, 1, 1])
ax.set_xlim(0, W)
ax.set_ylim(0, H)
ax.axis("off")

RX, RW = 0.04, 0.2          # left rail
CX = RX + RW + 0.07         # cards x
CW = W - CX - 0.04          # cards width
GAP = 0.075
heights = {1: 0.86, 2: 1.02, 3: 0.82, 4: 0.44, 5: 1.42, 6: 0.9, 7: 0.88}
phase_of = {1: "A", 2: "A", 3: "A", 4: "A", 5: "B", 6: "B", 7: "C"}


def img_ax(x, y, w, h):
    a = fig.add_axes([x / W, y / H, w / W, h / H])
    a.set_xticks([])
    a.set_yticks([])
    for s in a.spines.values():
        s.set_edgecolor(LINE)
        s.set_linewidth(0.4)
    return a


def card(n, y, h, title):
    col = PH[phase_of[n]][0]
    ax.add_patch(FancyBboxPatch((CX, y), CW, h, boxstyle="round,pad=0,rounding_size=0.045",
                                fc="white", ec=LINE, lw=0.55))
    ax.add_patch(Circle((CX + 0.13, y + h - 0.13), 0.07, fc=col, ec="none"))
    ax.text(CX + 0.13, y + h - 0.132, str(n), color="white", ha="center", va="center", fontsize=6.4, weight="bold")
    ax.text(CX + 0.25, y + h - 0.13, title, color=INK, fontsize=7.6, weight="bold", va="center")


def t(x, y, s, size=6.8, color=SUB, **kw):
    kw.setdefault("va", "top")
    kw.setdefault("linespacing", 1.3)
    ax.text(x, y, s, color=color, fontsize=size, **kw)


def arrow(x, y0, y1, col=SUB):
    ax.add_patch(FancyArrowPatch((x, y0), (x, y1), arrowstyle="-|>,head_width=0.05,head_length=0.06",
                                 mutation_scale=9, color=col, lw=0.7, shrinkA=0, shrinkB=0))


# ----- positions (top to bottom)
ys, y = {}, H - 0.06
for n in range(1, 8):
    y -= heights[n]
    ys[n] = y
    y -= GAP

# ----- left rail (one segment per phase)
for p, steps in (("A", [1, 2, 3, 4]), ("B", [5, 6]), ("C", [7])):
    col, light, name = PH[p]
    top = ys[steps[0]] + heights[steps[0]]
    bot = ys[steps[-1]]
    ax.add_patch(FancyBboxPatch((RX, bot), RW, top - bot, boxstyle="round,pad=0,rounding_size=0.05",
                                fc=light, ec="none"))
    ax.add_patch(Rectangle((RX + RW - 0.025, bot), 0.025, top - bot, fc=col, ec="none"))
    ax.text(RX + RW / 2 - 0.012, (top + bot) / 2, name, rotation=90, color=col, fontsize=7, weight="bold",
            ha="center", va="center")

# ----- 1 species selection (real shares, Milan)
n, y0, h = 1, ys[1], heights[1]
card(n, y0, h, "Species selection")
bc = list(csv.DictReader(open(ROOT / "refs/alba2025_zenodo/Bird_communities.csv", encoding="utf-8")))
codes = [k for k in bc[0] if k not in ("City", "Point", "Visit")]
# birikimli tur payi egrileri, 6 sehir (turler buyukten kucuge siralanmis)
city_tot = defaultdict(lambda: defaultdict(int))
for r in bc:
    for c in codes:
        city_tot[r["City"]][c] += int(r[c])
NMAX = 25
bx, by, bwid_, bhgt_ = CX + 0.17, y0 + 0.17, 0.98, 0.42
cax_ = img_ax(bx, by, bwid_, bhgt_)
for s_ in cax_.spines.values():
    s_.set_visible(False)
cax_.spines["left"].set_visible(True)
cax_.spines["bottom"].set_visible(True)
for s_ in ("left", "bottom"):
    cax_.spines[s_].set_color(SUB)
    cax_.spines[s_].set_linewidth(0.4)
shades = ["#9FB6CE", "#7C9BBB", "#5B80A8", "#3F6895", "#2F5D8A", "#1E4470"]
for col_, (city, d) in zip(shades, sorted(city_tot.items())):
    v = np.array(sorted(d.values(), reverse=True), float)
    v = np.cumsum(v / v.sum())
    k80 = int(np.searchsorted(v, 0.8))  # %80'i gecen tur (0-index)
    print(f"  {city}: %80 icin {k80 + 1} tur")
    v = v[:NMAX]
    cax_.plot(np.arange(1, len(v) + 1), v, color=col_, lw=0.8)
    cax_.plot(k80 + 1, v[k80], "o", color=col_, ms=1.8, mec="none")
cax_.axhline(0.8, color=K_ENL, lw=0.6, ls=(0, (2, 1.2)))
cax_.text(NMAX, 0.6, "80%", color=K_ENL, fontsize=6.2, ha="right", va="center")
cax_.set_xlim(0.5, NMAX + 0.5)
cax_.set_ylim(0.15, 1.02)
t(bx, by - 0.025, "Cumulative share, 6 cities", size=6.1)
tx = CX + 1.25
t(tx, y0 + h - 0.27, "Point counts in 6 Italian\ncities (Alba et al. 2025)")
t(tx, y0 + h - 0.56, "≥ 80% cumulative share\nper city; union")
ax.text(CX + CW - 0.12, y0 + 0.07, "25 species", color=PH["A"][0], fontsize=7.6, weight="bold", ha="right", va="bottom")

# ----- 2 images
n, y0, h = 2, ys[2], heights[2]
card(n, y0, h, "Image collection and screening")
tw = (CW - 0.3 - 5 * 0.04) / 6
for k, stem in enumerate(v4.THUMBS):
    im, b = v4.load(stem)
    c, _ = v4.crop(im, b, 0.68)
    img_ax(CX + 0.15 + k * (tw + 0.04), y0 + h - 0.27 - tw, tw, tw).imshow(c)
t(CX + 0.15, y0 + h - 0.31 - tw, "iNaturalist, research grade, CC0 / CC BY / CC BY-NC\n"
                                 "1,000 → 500 photos per species (12,500 in total)")

# ----- 3 annotation
n, y0, h = 3, ys[3], heights[3]
card(n, y0, h, "Tight box annotation")
im, B = v4.load(v4.MAIN)
cx, cy, bwid, bhgt = B
s_img = h - 0.33
c, o = v4.crop(im, B, 0.62)
a = img_ax(CX + 0.15, y0 + 0.08, s_img, s_img)
a.imshow(c)
a.add_patch(Rectangle((cx - bwid / 2 - o[0], cy - bhgt / 2 - o[1]), bwid, bhgt, fill=False, ec="#2E8B57", lw=0.9))
fx = CX + 0.3 + s_img
for i, (a1, a2) in enumerate([("YOLO11x", "COCO 'bird' proposals"), ("SAM 3", "mask → tightest box"),
                              ("Manual check", "all 13,403 boxes")]):
    yy = y0 + h - 0.36 - i * 0.165
    ax.text(fx, yy, a1, color=INK, fontsize=6.9, weight="bold", va="center")
    ax.text(fx + 0.78, yy, a2, color=SUB, fontsize=6.5, va="center")

# ----- 4 split
n, y0, h = 4, ys[4], heights[4]
card(n, y0, h, "Split by photographer")
xb, wb = CX + 1.55, CW - 1.55 - 0.12
for lab, num, fc, tc in (("train", 8730, PH["A"][0], "white"), ("val", 1885, "#86A3C0", "white"),
                         ("test", 1885, "#D5DFEA", INK)):
    ww = wb * num / 12500
    ax.add_patch(Rectangle((xb, y0 + h - 0.2), ww, 0.14, fc=fc, ec="white", lw=0.7))
    ax.text(xb + ww / 2, y0 + h - 0.13, lab, color=tc, fontsize=6.2, ha="center", va="center")
    xb += ww
t(CX + 0.25, y0 + h - 0.26, "8,730 / 1,885 / 1,885 images;  9,346 / 2,044 / 2,013 boxes", size=6.4)

# ----- 5 manipulation
n, y0, h = 5, ys[5], heights[5]
card(n, y0, h, "Training box-area manipulation")
s_img = 1.02
c, o = v4.crop(im, B, 0.66)
a = img_ax(CX + 0.15, y0 + 0.1, s_img, s_img)
a.imshow(c)
for k, col, ls in ((0.90, K_SHR, (0, (3, 1.5))), (1.00, K_ORI, "-"), (1.10, K_ENL, (0, (3, 1.5)))):
    s = np.sqrt(k)
    a.add_patch(Rectangle((cx - bwid * s / 2 - o[0], cy - bhgt * s / 2 - o[1]), bwid * s, bhgt * s,
                          fill=False, ec=col, lw=0.85, ls=ls))
lx = CX + 0.3 + s_img
for i, (col, ls, lab) in enumerate([(K_ENL, (0, (3, 1.5)), "k = 1.10  (+10%)"), (K_ORI, "-", "k = 1.00  (original)"),
                                    (K_SHR, (0, (3, 1.5)), "k = 0.90  (−10%)")]):
    yy = y0 + h - 0.34 - i * 0.14
    ax.plot([lx, lx + 0.17], [yy, yy], color=col, lw=0.9, ls=ls)
    ax.text(lx + 0.23, yy, lab, color=INK, fontsize=6.6, va="center")
t(lx, y0 + h - 0.7, "A′ = kA,  k = 1 + p/100\nw′ = √k·w,  h′ = √k·h", size=6.6, color=INK)
t(lx, y0 + 0.43, "21 levels, p = −10 … +10\nRandom: pᵢ ~ U(−10, 10)\nTraining labels only", size=6.5)

# ----- 6 training
n, y0, h = 6, ys[6], heights[6]
card(n, y0, h, "Model training")
rows = [("YOLOv8n", "21 levels × 2 seeds", "42"), ("YOLOv10n", "21 levels × 1 seed", "21"),
        ("YOLOv8n random", "3 seeds", "3")]
for i, (m, d, k) in enumerate(rows):
    yy = y0 + h - 0.36 - i * 0.145
    ax.text(CX + 0.25, yy, m, color=INK, fontsize=6.8, weight="bold", va="center")
    ax.text(CX + 1.3, yy, d, color=SUB, fontsize=6.6, va="center")
    ax.text(CX + CW - 0.14, yy, k, color=INK, fontsize=6.8, ha="right", va="center")
yl = y0 + h - 0.36 - 2 * 0.145 - 0.08
ax.plot([CX + 0.25, CX + CW - 0.14], [yl, yl], color=LINE, lw=0.5)
ax.text(CX + 0.25, yl - 0.09, "Same settings; only the box area differs", color=SUB, fontsize=6.4, va="center")
ax.text(CX + CW - 0.14, yl - 0.09, "66 models", color=PH["B"][0], fontsize=7.4, weight="bold", ha="right",
        va="center")

# ----- 7 evaluation
n, y0, h = 7, ys[7], heights[7]
card(n, y0, h, "Evaluation on tight test boxes")
chips = ["Tight (main)", "Class-agnostic", "Expanded test", "Rescaled by 1/k"]
cwid = (CW - 0.4 - 0.06) / 2
for i, lab in enumerate(chips):
    xx = CX + 0.25 + (i % 2) * (cwid + 0.06)
    yy = y0 + h - 0.4 - (i // 2) * 0.19
    ax.add_patch(FancyBboxPatch((xx, yy), cwid, 0.15, boxstyle="round,pad=0,rounding_size=0.05",
                                fc=PH["C"][1] if i else PH["C"][0], ec="none"))
    ax.text(xx + cwid / 2, yy + 0.075, lab, color="white" if i == 0 else INK, fontsize=6.5,
            ha="center", va="center", weight="bold" if i == 0 else "normal")
t(CX + 0.25, y0 + 0.27, "Per-species ΔAP50-95, box-area ratio, species\nconfusion, counting, city-weighted score", size=6.5)

# ----- arrows between cards
for n in range(1, 7):
    arrow(CX + CW / 2, ys[n] - 0.004, ys[n + 1] + heights[n + 1] + 0.004)

OUT.mkdir(parents=True, exist_ok=True)
fig.savefig(OUT / "fig_pipeline_v6.pdf", dpi=600)   # fotograflar 600 dpi gomulsun
fig.savefig(OUT / "fig_pipeline_v6.png", dpi=300)
fig.savefig(OUT / "fig_pipeline_v6.tif", dpi=600, pil_kwargs={"compression": "tiff_lzw"})
print(f"saved {OUT / 'fig_pipeline_v6.pdf'}  ({W * 25.4:.0f} x {H * 25.4:.0f} mm)")
