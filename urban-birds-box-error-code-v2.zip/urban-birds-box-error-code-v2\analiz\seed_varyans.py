"""Seed gurultusunun payi: AP50-95'in tur x seviye x seed varyans ayristirmasi (dengeli, iki yonlu ANOVA,
seed = hucre ici tekrar) ve ortalama kayba gore seed gurultusu.

    python analiz/seed_varyans.py
"""
import csv
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
R = [r for r in csv.DictReader(open(ROOT / "results_main/results.csv", encoding="utf-8"))
     if r["model"] == "yolov8n" and r["protocol"] == "tight" and r["class_id"] != "all"]
ap = {(int(float(r["margin"])), int(r["seed"]), int(r["class_id"])): 100 * float(r["AP50_95"]) for r in R}
levels = sorted(m for m in range(-10, 11) if all((m, s, c) in ap for s in (0, 1) for c in range(25)))
S, L, K = 25, len(levels), 2
Y = np.array([[[ap[(m, s, c)] for s in (0, 1)] for m in levels] for c in range(S)])  # tur x seviye x seed

g = Y.mean()
sp = Y.mean(axis=(1, 2))           # tur ortalamalari
lv = Y.mean(axis=(0, 2))           # seviye ortalamalari
cell = Y.mean(axis=2)              # tur x seviye
ss = {
    "Kutu hatasi seviyesi": S * K * ((lv - g) ** 2).sum(),
    "Tur (temel basarim farki)": L * K * ((sp - g) ** 2).sum(),
    "Tur x seviye (turlerin hataya farkli tepkisi)": K * ((cell - sp[:, None] - lv[None, :] + g) ** 2).sum(),
    "Seed (egitim rastgeleligi)": ((Y - cell[:, :, None]) ** 2).sum(),
}
df = {"Kutu hatasi seviyesi": L - 1, "Tur (temel basarim farki)": S - 1,
      "Tur x seviye (turlerin hataya farkli tepkisi)": (S - 1) * (L - 1), "Seed (egitim rastgeleligi)": S * L * (K - 1)}
tot = sum(ss.values())
print(f"Seviyeler: {levels[0]:+d} … {levels[-1]:+d} ({L} seviye), 25 tur, 2 seed  -> {Y.size} AP degeri\n")
print(f"{'Kaynak':48s} {'varyans payi':>12s} {'F':>8s}")
ms_e = ss["Seed (egitim rastgeleligi)"] / df["Seed (egitim rastgeleligi)"]
for k, v in ss.items():
    F = (v / df[k]) / ms_e if k != "Seed (egitim rastgeleligi)" else float("nan")
    print(f"{k:48s} {100 * v / tot:11.1f}% {F:8.1f}")

# etkilesimin ne kadari gercek? (varyans bileseni, ANOVA tahmini)
ms_int = ss["Tur x seviye (turlerin hataya farkli tepkisi)"] / df["Tur x seviye (turlerin hataya farkli tepkisi)"]
var_int = max(0.0, (ms_int - ms_e) / K)
print(f"\nTur x seviye etkilesimi: gercek varyans bileseni {var_int:.2f} pp², seed gurultusu {ms_e:.2f} pp²"
      f"  -> tek seed'de tur kaybi farklarinin ~%{100 * ms_e / (ms_e + var_int):.0f}'i gurultu")

# ortalama kayip duzeyinde: seed gurultusu kaybin yuzde kaci?
d = Y - Y[:, [levels.index(0)], :]                      # her seed kendi %0'ina gore dAP (tur bazinda)
md = d.mean(axis=0)                                      # seviye x seed, 25 tur ortalamasi
seed_diff = np.abs(md[:, 1] - md[:, 0])
loss = np.abs(md.mean(axis=1))
mask = np.array([abs(m) >= 3 for m in levels])
print(f"\nOrtalama dAP (25 tur) duzeyinde, |p| >= 3 seviyeler:")
print(f"  iki seed arasindaki fark ort. {seed_diff[mask].mean():.2f} pp, kayip ort. {loss[mask].mean():.2f} pp "
      f"-> gurultu/kayip = %{100 * seed_diff[mask].mean() / loss[mask].mean():.1f}")
for m in (-10, -5, 5):
    if m in levels:
        i = levels.index(m)
        print(f"  {m:+d}%: kayip {md[i].mean():+.2f} pp (seed0 {md[i, 0]:+.2f}, seed1 {md[i, 1]:+.2f}) "
              f"-> fark kaybin %{100 * seed_diff[i] / loss[i]:.1f}'i")
